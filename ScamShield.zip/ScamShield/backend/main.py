import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .database import init_db, get_stats
from .services.notification_service import notification_service
from .api import (
    agent_router,
    messages_router,
    alerts_router,
    history_router,
    sources_router,
    settings_router,
    gmail_router
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize SQLite database
    init_db()
    yield
    # Shutdown

app = FastAPI(
    title="ScamShield AI Protection Agent",
    description="Proactive AI-Powered Incoming Message Scam Detection & Protection Agent API",
    version="2.0.0",
    lifespan=lifespan
)

# Enable CORS for frontend clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Routers
app.include_router(agent_router)
app.include_router(messages_router)
app.include_router(alerts_router)
app.include_router(history_router)
app.include_router(sources_router)
app.include_router(settings_router)
app.include_router(gmail_router)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await notification_service.connect(websocket)
    try:
        # Send initial sync payload
        stats = get_stats()
        await websocket.send_json({
            "event": "INITIAL_SYNC",
            "data": {
                "status": "connected",
                "stats": stats
            }
        })
        while True:
            # Keep connection alive, listen for client heartbeats or test triggers
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        notification_service.disconnect(websocket)
    except Exception:
        notification_service.disconnect(websocket)

# Check and mount compiled frontend static files if present
frontend_dist = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "dist"))
if os.path.exists(frontend_dist):
    app.mount("/assets", StaticFiles(directory=os.path.join(frontend_dist, "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        # Allow API routes and Docs to proceed normally
        if full_path.startswith("api") or full_path.startswith("docs") or full_path.startswith("openapi.json"):
            return None
        file_path = os.path.join(frontend_dist, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(frontend_dist, "index.html"))
else:
    @app.get("/")
    async def root():
        return {
            "service": "ScamShield Agent Backend",
            "tagline": "Detect. Understand. Stay Safe.",
            "status": "online",
            "docs_url": "/docs"
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
