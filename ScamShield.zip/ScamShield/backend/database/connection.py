import sqlite3
import json
import os
import hashlib
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scamshield.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS message_sources (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        source_type TEXT NOT NULL,
        status TEXT NOT NULL,
        permission_status TEXT NOT NULL,
        permission_info TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT NOT NULL,
        message_count INTEGER DEFAULT 0,
        last_synced TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS analyses (
        id TEXT PRIMARY KEY,
        message_id TEXT NOT NULL,
        source TEXT NOT NULL,
        sender TEXT NOT NULL,
        content_preview TEXT NOT NULL,
        full_content TEXT,
        timestamp TEXT NOT NULL,
        risk_score INTEGER NOT NULL,
        risk_level TEXT NOT NULL,
        category TEXT NOT NULL,
        summary TEXT NOT NULL,
        recommendations_json TEXT NOT NULL,
        technical_details_json TEXT NOT NULL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS analysis_reasons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        analysis_id TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        severity TEXT NOT NULL,
        FOREIGN KEY(analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS analysis_urls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        analysis_id TEXT NOT NULL,
        url TEXT NOT NULL,
        domain TEXT NOT NULL,
        is_https INTEGER NOT NULL,
        is_ip_address INTEGER NOT NULL,
        is_shortener INTEGER NOT NULL,
        is_lookalike INTEGER NOT NULL,
        flags_json TEXT NOT NULL,
        risk_contribution INTEGER NOT NULL,
        FOREIGN KEY(analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id TEXT PRIMARY KEY,
        analysis_id TEXT NOT NULL,
        risk_level TEXT NOT NULL,
        risk_score INTEGER NOT NULL,
        category TEXT NOT NULL,
        sender TEXT NOT NULL,
        summary TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        FOREIGN KEY(analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
    )
    """)

    # Seed clean default message sources (All counts start at 0)
    cursor.execute("SELECT COUNT(*) FROM message_sources")
    if cursor.fetchone()[0] == 0:
        default_sources = [
            (
                "src-gmail",
                "Gmail Inbound Monitor",
                "GMAIL",
                "CONNECTED",
                "GRANTED",
                "Direct Gmail IMAP sync / Inbound web parser integration",
                "Monitors incoming Gmail emails, phishing lures, and malicious attachments",
                "mail",
                0,
                None
            ),
            (
                "src-sms",
                "Android SMS Service",
                "SMS",
                "CONNECTED",
                "GRANTED",
                "SMS_RECEIVE and READ_SMS permission granted via ScamShield Mobile Bridge",
                "Monitors incoming SMS messages before they are opened",
                "smartphone",
                0,
                None
            ),
            (
                "src-messaging",
                "Messaging App Connector",
                "MESSAGING_API",
                "RESTRICTED",
                "REQUIRED",
                "This message source requires permission or an approved integration.",
                "Direct API access to WhatsApp, Telegram, or Instagram requires official business webhook or accessibility listener authorization.",
                "message-square",
                0,
                None
            ),
            (
                "src-demo",
                "Demo Simulator Stream",
                "DEMO",
                "CONNECTED",
                "GRANTED",
                "Simulation feed for safe live threat demonstration and testing",
                "Generates realistic phishing, fake KYC, prize scam, job fraud, and safe messages",
                "cpu",
                0,
                None
            ),
            (
                "src-webhook",
                "Security Ingestion Webhook",
                "WEBHOOK",
                "CONNECTED",
                "GRANTED",
                "Incoming HTTPS webhook token: scm_live_sec_token_9921",
                "Accepts enterprise or custom client payload pushes directly into the ScamShield agent",
                "globe",
                0,
                None
            )
        ]
        cursor.executemany("""
            INSERT INTO message_sources 
            (id, name, source_type, status, permission_status, permission_info, description, icon, message_count, last_synced)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, default_sources)

    # Seed default settings if empty
    cursor.execute("SELECT COUNT(*) FROM settings")
    if cursor.fetchone()[0] == 0:
        default_settings = {
            "protection_enabled": "true",
            "auto_alert_high": "true",
            "auto_alert_suspicious": "true",
            "high_risk_threshold": "70",
            "suspicious_threshold": "30",
            "privacy_minimal_metadata": "true",
            "data_retention_days": "30",
            "sound_alerts": "true",
            "gmail_email": "",
            "gmail_app_password": "",
            "gmail_connected": "false",
            "gmail_last_sync": ""
        }
        for k, v in default_settings.items():
            cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()

def wipe_all_data():
    """Wipes out all analyzed messages, alerts, reasons, urls, and resets source counts to 0"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM alerts")
    cursor.execute("DELETE FROM analysis_reasons")
    cursor.execute("DELETE FROM analysis_urls")
    cursor.execute("DELETE FROM analyses")
    cursor.execute("UPDATE message_sources SET message_count = 0, last_synced = NULL")
    conn.commit()
    conn.close()

def get_settings() -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings")
    rows = cursor.fetchall()
    conn.close()
    result = {}
    for row in rows:
        val = row["value"]
        if val.lower() == "true":
            result[row["key"]] = True
        elif val.lower() == "false":
            result[row["key"]] = False
        elif val.isdigit():
            result[row["key"]] = int(val)
        else:
            result[row["key"]] = val
    return result

def update_settings(updates: Dict[str, Any]):
    conn = get_connection()
    cursor = conn.cursor()
    for k, v in updates.items():
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v).lower() if isinstance(v, bool) else str(v)))
    conn.commit()
    conn.close()

def get_sources() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM message_sources")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def update_source_status(source_id: str, status: str, permission_status: Optional[str] = None):
    conn = get_connection()
    cursor = conn.cursor()
    if permission_status:
        cursor.execute("UPDATE message_sources SET status = ?, permission_status = ? WHERE id = ?", (status, permission_status, source_id))
    else:
        cursor.execute("UPDATE message_sources SET status = ? WHERE id = ?", (status, source_id))
    conn.commit()
    conn.close()

def increment_source_count(source_type: str):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE message_sources 
        SET message_count = message_count + 1, last_synced = ? 
        WHERE source_type = ? OR id = ?
    """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), source_type, source_type))
    conn.commit()
    conn.close()

def save_analysis(analysis_data: Dict[str, Any], raw_content: str, privacy_minimal: bool = True) -> str:
    conn = get_connection()
    cursor = conn.cursor()

    preview = analysis_data["content_preview"]
    stored_full = None
    if not privacy_minimal:
        stored_full = raw_content
    else:
        stored_full = f"[Privacy Protected] Hash: {hashlib.sha256(raw_content.encode()).hexdigest()[:16]}"

    cursor.execute("""
        INSERT INTO analyses (
            id, message_id, source, sender, content_preview, full_content,
            timestamp, risk_score, risk_level, category, summary,
            recommendations_json, technical_details_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        analysis_data["id"],
        analysis_data["message_id"],
        analysis_data["source"],
        analysis_data["sender"],
        preview,
        stored_full,
        analysis_data["timestamp"],
        analysis_data["risk_score"],
        analysis_data["risk_level"],
        analysis_data["category"],
        analysis_data["summary"],
        json.dumps(analysis_data["recommendations"]),
        json.dumps(analysis_data.get("technical_details", {}))
    ))

    for reason in analysis_data.get("reasons", []):
        cursor.execute("""
            INSERT INTO analysis_reasons (analysis_id, title, description, severity)
            VALUES (?, ?, ?, ?)
        """, (analysis_data["id"], reason["title"], reason["description"], reason.get("severity", "MEDIUM")))

    for url_res in analysis_data.get("urls_detected", []):
        cursor.execute("""
            INSERT INTO analysis_urls (
                analysis_id, url, domain, is_https, is_ip_address, is_shortener, is_lookalike, flags_json, risk_contribution
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            analysis_data["id"],
            url_res["url"],
            url_res["domain"],
            1 if url_res.get("is_https") else 0,
            1 if url_res.get("is_ip_address") else 0,
            1 if url_res.get("is_shortener") else 0,
            1 if url_res.get("is_lookalike") else 0,
            json.dumps(url_res.get("suspicious_flags", [])),
            url_res.get("risk_contribution", 0)
        ))

    # Create alert if risk is SUSPICIOUS or HIGH
    if analysis_data["risk_level"] in ["SUSPICIOUS", "HIGH"]:
        alert_id = f"alt-{analysis_data['id']}"
        cursor.execute("""
            INSERT INTO alerts (id, analysis_id, risk_level, risk_score, category, sender, summary, timestamp, is_read)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
        """, (
            alert_id,
            analysis_data["id"],
            analysis_data["risk_level"],
            analysis_data["risk_score"],
            analysis_data["category"],
            analysis_data["sender"],
            analysis_data["summary"],
            analysis_data["timestamp"]
        ))

    conn.commit()
    conn.close()
    return analysis_data["id"]

def get_analyses(limit: int = 50, risk_filter: Optional[str] = None, search: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM analyses WHERE 1=1"
    params = []

    if risk_filter and risk_filter.upper() != "ALL":
        query += " AND risk_level = ?"
        params.append(risk_filter.upper())

    if search:
        query += " AND (sender LIKE ? OR content_preview LIKE ? OR category LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term, term])

    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)

    cursor.execute(query, params)
    rows = cursor.fetchall()
    analyses = []

    for row in rows:
        item = dict(row)
        item["recommendations"] = json.loads(item["recommendations_json"])
        item["technical_details"] = json.loads(item["technical_details_json"])

        cursor.execute("SELECT title, description, severity FROM analysis_reasons WHERE analysis_id = ?", (item["id"],))
        item["reasons"] = [dict(r) for r in cursor.fetchall()]

        cursor.execute("SELECT url, domain, is_https, is_ip_address, is_shortener, is_lookalike, flags_json, risk_contribution FROM analysis_urls WHERE analysis_id = ?", (item["id"],))
        url_rows = cursor.fetchall()
        item["urls_detected"] = []
        for ur in url_rows:
            u_dict = dict(ur)
            u_dict["is_https"] = bool(u_dict["is_https"])
            u_dict["is_ip_address"] = bool(u_dict["is_ip_address"])
            u_dict["is_shortener"] = bool(u_dict["is_shortener"])
            u_dict["is_lookalike"] = bool(u_dict["is_lookalike"])
            u_dict["suspicious_flags"] = json.loads(u_dict["flags_json"])
            item["urls_detected"].append(u_dict)

        analyses.append(item)

    conn.close()
    return analyses

def get_analysis_by_id(analysis_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None

    item = dict(row)
    item["recommendations"] = json.loads(item["recommendations_json"])
    item["technical_details"] = json.loads(item["technical_details_json"])

    cursor.execute("SELECT title, description, severity FROM analysis_reasons WHERE analysis_id = ?", (item["id"],))
    item["reasons"] = [dict(r) for r in cursor.fetchall()]

    cursor.execute("SELECT url, domain, is_https, is_ip_address, is_shortener, is_lookalike, flags_json, risk_contribution FROM analysis_urls WHERE analysis_id = ?", (item["id"],))
    url_rows = cursor.fetchall()
    item["urls_detected"] = []
    for ur in url_rows:
        u_dict = dict(ur)
        u_dict["is_https"] = bool(u_dict["is_https"])
        u_dict["is_ip_address"] = bool(u_dict["is_ip_address"])
        u_dict["is_shortener"] = bool(u_dict["is_shortener"])
        u_dict["is_lookalike"] = bool(u_dict["is_lookalike"])
        u_dict["suspicious_flags"] = json.loads(u_dict["flags_json"])
        item["urls_detected"].append(u_dict)

    conn.close()
    return item

def delete_analysis(analysis_id: str) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM alerts WHERE analysis_id = ?", (analysis_id,))
    cursor.execute("DELETE FROM analysis_reasons WHERE analysis_id = ?", (analysis_id,))
    cursor.execute("DELETE FROM analysis_urls WHERE analysis_id = ?", (analysis_id,))
    cursor.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted

def clear_all_history() -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM alerts")
    cursor.execute("DELETE FROM analysis_reasons")
    cursor.execute("DELETE FROM analysis_urls")
    cursor.execute("DELETE FROM analyses")
    count = cursor.rowcount
    conn.commit()
    conn.close()
    return count

def get_alerts(unread_only: bool = False) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM alerts"
    if unread_only:
        query += " WHERE is_read = 0"
    query += " ORDER BY timestamp DESC"
    cursor.execute(query)
    rows = cursor.fetchall()
    alerts = []
    for r in rows:
        alt = dict(r)
        alt["is_read"] = bool(alt["is_read"])
        cursor.execute("SELECT title FROM analysis_reasons WHERE analysis_id = ?", (alt["analysis_id"],))
        alt["reasons_summary"] = [row["title"] for row in cursor.fetchall()]
        alerts.append(alt)
    conn.close()
    return alerts

def mark_alert_read(alert_id: str):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE alerts SET is_read = 1 WHERE id = ?", (alert_id,))
    conn.commit()
    conn.close()

def mark_all_alerts_read():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE alerts SET is_read = 1")
    conn.commit()
    conn.close()

def get_stats() -> Dict[str, Any]:
    """Accurate live stats reflecting actual messages checked with zero artificial offsets"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM analyses")
    total_checked = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE risk_level IN ('SUSPICIOUS', 'HIGH')")
    threats_live = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE risk_level = 'HIGH'")
    high_live = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM analyses WHERE risk_level = 'SUSPICIOUS'")
    suspicious_live = cursor.fetchone()[0]

    conn.close()

    return {
        "messages_checked": total_checked,
        "threats_detected": threats_live,
        "high_risk_count": high_live,
        "suspicious_count": suspicious_live
    }
