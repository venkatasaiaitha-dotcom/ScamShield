from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime

from ..database import (
    get_settings,
    update_settings,
    update_source_status,
    wipe_all_data,
    get_stats
)
from ..services.gmail_service import gmail_service
from ..agents.scamshield_agent import scamshield_agent
from ..services.notification_service import notification_service

router = APIRouter(prefix="/api/gmail", tags=["Gmail Integration"])

class GmailConnectRequest(BaseModel):
    email: str
    app_password: str

class GmailInputRequest(BaseModel):
    sender: str
    subject: str
    body: str

@router.get("/status")
async def get_gmail_status():
    settings = get_settings()
    email_addr = settings.get("gmail_email", "")
    is_connected = settings.get("gmail_connected", False)
    last_sync = settings.get("gmail_last_sync", "")

    # Mask email address for privacy
    masked_email = ""
    if email_addr and "@" in email_addr:
        parts = email_addr.split("@")
        masked_email = f"{parts[0][:3]}***@{parts[1]}"

    return {
        "connected": bool(is_connected),
        "email": email_addr,
        "masked_email": masked_email,
        "last_sync": last_sync
    }

@router.post("/connect")
async def connect_gmail(req: GmailConnectRequest):
    if not req.email or not req.app_password:
        raise HTTPException(status_code=400, detail="Gmail address and 16-character App Password are required.")

    # Verify IMAP login
    success, message = gmail_service.test_connection(req.email, req.app_password)
    if not success:
        raise HTTPException(status_code=401, detail=message)

    # Save credentials and mark source active
    update_settings({
        "gmail_email": req.email.strip(),
        "gmail_app_password": req.app_password.strip(),
        "gmail_connected": "true",
        "gmail_last_sync": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    update_source_status("src-gmail", "CONNECTED", "GRANTED")

    return {
        "status": "success",
        "message": f"Successfully connected to Gmail for {req.email}."
    }

@router.post("/disconnect")
async def disconnect_gmail():
    update_settings({
        "gmail_app_password": "",
        "gmail_connected": "false"
    })
    update_source_status("src-gmail", "DISCONNECTED", "REQUIRED")
    return {"status": "success", "message": "Gmail account disconnected."}

@router.post("/sync")
async def sync_gmail():
    """
    Connects to Gmail, fetches latest unread or recent messages,
    and runs each through the proactive ScamShield AI Agent.
    """
    settings = get_settings()
    email_addr = settings.get("gmail_email", "")
    app_pwd = settings.get("gmail_app_password", "")

    if not email_addr or not app_pwd:
        raise HTTPException(
            status_code=400,
            detail="Gmail is not configured. Please connect your Gmail address and App Password first."
        )

    try:
        messages = gmail_service.fetch_recent_messages(email_addr, app_pwd, max_emails=5, unread_only=True)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch emails from Gmail: {str(e)}")

    if not messages:
        return {
            "status": "success",
            "messages_checked": 0,
            "analyses": [],
            "message": "No new emails found in your Gmail inbox."
        }

    analyses = []
    for msg in messages:
        res = await scamshield_agent.process_incoming_message(msg, default_source="GMAIL")
        analyses.append(res)

    update_settings({"gmail_last_sync": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})

    return {
        "status": "success",
        "messages_checked": len(analyses),
        "analyses": analyses,
        "message": f"Successfully analyzed {len(analyses)} incoming message(s) from Gmail."
    }

@router.post("/input")
async def input_gmail_message(req: GmailInputRequest):
    """
    Directly takes input from a Gmail message (Sender, Subject, Body)
    and automatically inspects it through ScamShield.
    """
    full_content = f"Subject: {req.subject.strip()}\n\n{req.body.strip()}"
    msg_payload = {
        "source": "GMAIL",
        "sender": req.sender.strip() or "Google Mail Inbound",
        "recipient": "You",
        "content": full_content,
        "timestamp": datetime.now().strftime("%I:%M %p"),
        "metadata": {
            "subject": req.subject.strip(),
            "channel": "GMAIL_WEB_INPUT"
        }
    }

    res = await scamshield_agent.process_incoming_message(msg_payload, default_source="GMAIL")
    return res

# Admin / Wipe Endpoint
@router.post("/wipe-data")
async def wipe_data():
    """Wipes out all analyzed messages, alerts, reasons, urls, and resets all stats to 0"""
    wipe_all_data()
    stats = get_stats()
    # Broadcast reset to frontend WebSocket clients
    await notification_service.broadcast("DATA_WIPED", {
        "stats": stats,
        "message": "All data wiped successfully"
    })
    return {
        "status": "success",
        "message": "All database messages, alerts, and metrics have been completely wiped out.",
        "stats": stats
    }
