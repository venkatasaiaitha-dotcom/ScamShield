from fastapi import APIRouter, HTTPException
from typing import Dict, Any, Optional
from pydantic import BaseModel
from ..models.schemas import IncomingMessage, MessageAnalysis, URLAnalysisResult
from ..agents.scamshield_agent import scamshield_agent
from ..connectors.demo_connector import DEMO_SCENARIOS
from ..services.url_analyzer import URLAnalyzer
from ..ml.classifier import classifier

router = APIRouter(prefix="/api", tags=["Messages & Analysis"])

class ScenarioRequest(BaseModel):
    scenario_type: Optional[str] = "RANDOM"

class URLCheckRequest(BaseModel):
    url: str

class MessageCheckRequest(BaseModel):
    content: str
    sender: Optional[str] = "Manual Inspection"

@router.get("/messages/scenarios")
async def list_scenarios():
    return DEMO_SCENARIOS

@router.post("/messages/incoming")
async def receive_incoming_message(msg: IncomingMessage):
    """
    Receives incoming message from any connected source (SMS, Email, Webhook, Demo)
    and automatically processes it through the ScamShield AI Agent.
    """
    res = await scamshield_agent.process_incoming_message(msg.model_dump(), default_source=msg.source)
    return res

@router.post("/messages/simulate-scenario")
async def simulate_scenario(req: ScenarioRequest):
    """
    Triggers an incoming message simulation from the preset test scenarios
    or random stream to demonstrate the proactive AI agent in action.
    """
    generated = scamshield_agent.demo_connector.generate_scenario(req.scenario_type)
    res = await scamshield_agent.process_incoming_message(generated, default_source="DEMO")
    return res

@router.post("/analyze/message")
async def analyze_message_direct(req: MessageCheckRequest):
    """
    Ad-hoc manual inspection endpoint if user explicitly requests analysis.
    """
    res = classifier.process(req.content, req.sender or "Manual Inspection")
    return res

@router.post("/analyze/url")
async def analyze_url_direct(req: URLCheckRequest):
    """
    Safe server-side URL inspection endpoint.
    """
    res = URLAnalyzer.analyze_url(req.url)
    return res
