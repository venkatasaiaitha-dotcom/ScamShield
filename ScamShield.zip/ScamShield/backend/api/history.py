from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..database import get_analyses, get_analysis_by_id, delete_analysis, clear_all_history
from ..models.schemas import MessageAnalysis

router = APIRouter(prefix="/api/history", tags=["History"])

@router.get("", response_model=List[MessageAnalysis])
async def list_history(
    limit: int = Query(50, ge=1, le=200),
    risk: Optional[str] = None,
    search: Optional[str] = None
):
    return get_analyses(limit=limit, risk_filter=risk, search=search)

@router.get("/{analysis_id}", response_model=MessageAnalysis)
async def get_history_detail(analysis_id: str):
    res = get_analysis_by_id(analysis_id)
    if not res:
        raise HTTPException(status_code=404, detail="Analysis record not found")
    return res

@router.delete("/{analysis_id}")
async def remove_history_entry(analysis_id: str):
    deleted = delete_analysis(analysis_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Analysis record not found")
    return {"status": "success", "message": "Record deleted", "id": analysis_id}

@router.post("/clear")
async def clear_history():
    count = clear_all_history()
    return {"status": "success", "deleted_count": count, "message": "All protection logs cleared for privacy"}
