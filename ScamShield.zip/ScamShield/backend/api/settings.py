from fastapi import APIRouter
from typing import Dict, Any
from ..database import get_settings, update_settings
from ..models.schemas import SettingsModel

router = APIRouter(prefix="/api/settings", tags=["Settings"])

@router.get("", response_model=SettingsModel)
async def fetch_settings():
    s = get_settings()
    return SettingsModel(**s)

@router.post("", response_model=SettingsModel)
async def save_settings(new_settings: SettingsModel):
    update_settings(new_settings.model_dump())
    s = get_settings()
    return SettingsModel(**s)
