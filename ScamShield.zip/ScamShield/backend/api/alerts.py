from fastapi import APIRouter
from typing import List, Optional
from ..database import get_alerts, mark_alert_read, mark_all_alerts_read
from ..models.schemas import AlertItem

router = APIRouter(prefix="/api/alerts", tags=["Alerts"])

@router.get("", response_model=List[AlertItem])
async def list_alerts(unread_only: bool = False):
    return get_alerts(unread_only=unread_only)

@router.post("/{alert_id}/read")
async def mark_read(alert_id: str):
    mark_alert_read(alert_id)
    return {"status": "success", "id": alert_id, "is_read": True}

@router.post("/mark-all-read")
async def mark_all_read():
    mark_all_alerts_read()
    return {"status": "success", "message": "All alerts marked as read"}
