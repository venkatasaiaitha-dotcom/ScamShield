from fastapi import APIRouter
from ..models.schemas import AgentStatusResponse
from ..agents.scamshield_agent import scamshield_agent

router = APIRouter(prefix="/api/agent", tags=["Agent"])

@router.get("/status", response_model=AgentStatusResponse)
async def get_agent_status():
    return scamshield_agent.get_status()

@router.post("/start")
async def start_protection():
    scamshield_agent.set_protection_status(True)
    return {"status": "success", "protection_active": True, "message": "Protection Active - Monitoring connected sources"}

@router.post("/pause")
async def pause_protection():
    scamshield_agent.set_protection_status(False)
    return {"status": "success", "protection_active": False, "message": "Protection Paused - Incoming messages will not be automatically analyzed"}
