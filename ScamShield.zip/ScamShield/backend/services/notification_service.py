import json
import asyncio
from typing import Set, Dict, Any
from fastapi import WebSocket

class NotificationService:
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)

    async def broadcast(self, event_type: str, data: Dict[str, Any]):
        """Broadcasts event payload to all connected frontend clients"""
        if not self.active_connections:
            return

        payload = json.dumps({
            "event": event_type,
            "data": data
        })

        dead_connections = set()
        for connection in list(self.active_connections):
            try:
                await connection.send_text(payload)
            except Exception:
                dead_connections.add(connection)

        for dead in dead_connections:
            self.active_connections.discard(dead)

    async def dispatch_analysis_event(self, analysis_dict: Dict[str, Any], stats_dict: Dict[str, Any]):
        risk_level = analysis_dict["risk_level"]
        risk_score = analysis_dict["risk_score"]

        # Adaptive notification priority flag
        notification_tier = "NONE"
        if risk_level == "HIGH" or risk_score >= 70:
            notification_tier = "PROMINENT_ALERT"
        elif risk_level == "SUSPICIOUS" or risk_score >= 30:
            notification_tier = "SUBTLE_NOTICE"

        await self.broadcast("MESSAGE_PROCESSED", {
            "analysis": analysis_dict,
            "stats": stats_dict,
            "notification_tier": notification_tier
        })

notification_service = NotificationService()
