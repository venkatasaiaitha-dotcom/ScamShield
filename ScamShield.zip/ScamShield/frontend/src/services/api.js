const API_BASE = '/api';

export const api = {
  // Agent Status & Controls
  async getAgentStatus() {
    const res = await fetch(`${API_BASE}/agent/status`);
    if (!res.ok) throw new Error('Failed to fetch agent status');
    return res.json();
  },

  async startProtection() {
    const res = await fetch(`${API_BASE}/agent/start`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to enable protection');
    return res.json();
  },

  async pauseProtection() {
    const res = await fetch(`${API_BASE}/agent/pause`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to pause protection');
    return res.json();
  },

  // Incoming Messages & Simulator
  async simulateScenario(scenarioType = 'RANDOM') {
    const res = await fetch(`${API_BASE}/messages/simulate-scenario`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scenario_type: scenarioType }),
    });
    if (!res.ok) throw new Error('Failed to simulate scenario');
    return res.json();
  },

  async sendIncomingMessage(messageData) {
    const res = await fetch(`${API_BASE}/messages/incoming`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(messageData),
    });
    if (!res.ok) throw new Error('Failed to send incoming message');
    return res.json();
  },

  async getScenarios() {
    const res = await fetch(`${API_BASE}/messages/scenarios`);
    if (!res.ok) throw new Error('Failed to fetch scenarios');
    return res.json();
  },

  // Alerts
  async getAlerts(unreadOnly = false) {
    const res = await fetch(`${API_BASE}/alerts?unread_only=${unreadOnly}`);
    if (!res.ok) throw new Error('Failed to fetch alerts');
    return res.json();
  },

  async markAlertRead(alertId) {
    const res = await fetch(`${API_BASE}/alerts/${alertId}/read`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to mark alert as read');
    return res.json();
  },

  async markAllAlertsRead() {
    const res = await fetch(`${API_BASE}/alerts/mark-all-read`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to mark all alerts as read');
    return res.json();
  },

  // History
  async getHistory(risk = 'ALL', search = '', limit = 50) {
    let url = `${API_BASE}/history?limit=${limit}`;
    if (risk && risk !== 'ALL') url += `&risk=${risk}`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch history');
    return res.json();
  },

  async getHistoryDetail(analysisId) {
    const res = await fetch(`${API_BASE}/history/${analysisId}`);
    if (!res.ok) throw new Error('Failed to fetch analysis details');
    return res.json();
  },

  async deleteHistoryEntry(analysisId) {
    const res = await fetch(`${API_BASE}/history/${analysisId}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete history entry');
    return res.json();
  },

  async clearAllHistory() {
    const res = await fetch(`${API_BASE}/history/clear`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to clear history');
    return res.json();
  },

  // Sources
  async getSources() {
    const res = await fetch(`${API_BASE}/sources`);
    if (!res.ok) throw new Error('Failed to fetch sources');
    return res.json();
  },

  async connectSource(sourceId) {
    const res = await fetch(`${API_BASE}/sources/${sourceId}/connect`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to connect source');
    return res.json();
  },

  async disconnectSource(sourceId) {
    const res = await fetch(`${API_BASE}/sources/${sourceId}/disconnect`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to disconnect source');
    return res.json();
  },

  // Settings
  async getSettings() {
    const res = await fetch(`${API_BASE}/settings`);
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async updateSettings(settings) {
    const res = await fetch(`${API_BASE}/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update settings');
    return res.json();
  },

  // Gmail Integration
  async getGmailStatus() {
    const res = await fetch(`${API_BASE}/gmail/status`);
    if (!res.ok) throw new Error('Failed to fetch Gmail status');
    return res.json();
  },

  async connectGmail(email, appPassword) {
    const res = await fetch(`${API_BASE}/gmail/connect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, app_password: appPassword }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to authenticate Gmail');
    return data;
  },

  async disconnectGmail() {
    const res = await fetch(`${API_BASE}/gmail/disconnect`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to disconnect Gmail');
    return res.json();
  },

  async syncGmail() {
    const res = await fetch(`${API_BASE}/gmail/sync`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to sync Gmail');
    return data;
  },

  async inputGmailMessage(messageData) {
    const res = await fetch(`${API_BASE}/gmail/input`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(messageData),
    });
    if (!res.ok) throw new Error('Failed to process Gmail message');
    return res.json();
  },

  // Complete System Data Wipe
  async wipeAllData() {
    const res = await fetch(`${API_BASE}/gmail/wipe-data`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to wipe data');
    return res.json();
  },
};

// WebSocket Real-time subscriber
export function createWebSocketClient(onMessage, onStatusChange) {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws`;

  let ws = null;
  let reconnectTimer = null;
  let heartbeatTimer = null;

  function connect() {
    try {
      ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        if (onStatusChange) onStatusChange(true);
        heartbeatTimer = setInterval(() => {
          if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send('ping');
          }
        }, 15000);
      };

      ws.onmessage = (event) => {
        try {
          if (event.data === 'pong') return;
          const parsed = JSON.parse(event.data);
          if (onMessage) onMessage(parsed);
        } catch {
          // ignore non-json ping/pong
        }
      };

      ws.onclose = () => {
        if (onStatusChange) onStatusChange(false);
        clearInterval(heartbeatTimer);
        reconnectTimer = setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        if (ws) ws.close();
      };
    } catch {
      reconnectTimer = setTimeout(connect, 3000);
    }
  }

  connect();

  return {
    disconnect() {
      clearTimeout(reconnectTimer);
      clearInterval(heartbeatTimer);
      if (ws) ws.close();
    },
  };
}

// Subtle audio alert helper using Web Audio API (no external asset file dependencies)
export function playAlertChime(isHighRisk = true) {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (isHighRisk) {
      // 2-tone alert chime
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880.00, ctx.currentTime + 0.12); // A5
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.35);
    } else {
      // Subtle notice ping
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, ctx.currentTime); // E5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.2);
    }
  } catch {
    // Audio context may be blocked by browser policy until user interacts
  }
}
