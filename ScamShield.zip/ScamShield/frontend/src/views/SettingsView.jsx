import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Bell,
  Lock,
  Sliders,
  Trash2,
  CheckCircle,
  Volume2,
  Info,
  Save,
  Loader2,
} from 'lucide-react';

export default function SettingsView({
  settings,
  onSaveSettings,
  onClearHistory,
}) {
  const [formData, setFormData] = useState({ ...settings });
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const handleChange = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSaveSettings(formData);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-6 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              System Settings & Privacy Controls
            </h2>
            <p className="text-xs text-slate-400">
              Configure ScamShield AI detection sensitivity, notifications, and privacy options
            </p>
          </div>
        </div>

        {savedSuccess && (
          <span className="flex items-center space-x-1.5 text-xs text-emerald-400 font-semibold px-3 py-1 rounded-lg bg-emerald-950/80 border border-emerald-800">
            <CheckCircle className="w-4 h-4" />
            <span>Settings Saved!</span>
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Protection & Detection Preferences */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>AI Agent Protection</span>
          </h3>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-200 block">
                  Active Protection
                </span>
                <span className="text-[11px] text-slate-400">
                  Continuously inspect incoming messages from connected channels
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.protection_enabled}
                onChange={(e) => handleChange('protection_enabled', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-200 block">
                  Prominent High-Risk Warning Modals
                </span>
                <span className="text-[11px] text-slate-400">
                  Instantly open focused action guidance when a dangerous scam is detected
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.auto_alert_high}
                onChange={(e) => handleChange('auto_alert_high', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-200 block">
                  Audio Alert Chimes
                </span>
                <span className="text-[11px] text-slate-400">
                  Play subtle acoustic alert when dangerous messages are flagged
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.sound_alerts}
                onChange={(e) => handleChange('sound_alerts', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>
          </div>
        </div>

        {/* Risk Thresholds */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>Risk Sensitivity Thresholds</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-300">
                  High-Risk Threshold
                </span>
                <span className="text-xs font-mono font-bold text-rose-400">
                  {formData.high_risk_threshold}/100
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="90"
                step="5"
                value={formData.high_risk_threshold}
                onChange={(e) => handleChange('high_risk_threshold', parseInt(e.target.value))}
                className="w-full accent-rose-500"
              />
              <span className="text-[10px] text-slate-500 block">
                Messages at or above this score trigger immediate high-priority alerts
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-amber-300">
                  Suspicious Threshold
                </span>
                <span className="text-xs font-mono font-bold text-amber-400">
                  {formData.suspicious_threshold}/100
                </span>
              </div>
              <input
                type="range"
                min="20"
                max="50"
                step="5"
                value={formData.suspicious_threshold}
                onChange={(e) => handleChange('suspicious_threshold', parseInt(e.target.value))}
                className="w-full accent-amber-500"
              />
              <span className="text-[10px] text-slate-500 block">
                Messages at or above this score trigger cautious advisory notifications
              </span>
            </div>
          </div>
        </div>

        {/* Privacy-First Design Controls (Requirement #19) */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>Privacy-First Architecture</span>
          </h3>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer">
              <div className="pr-4">
                <span className="text-xs font-semibold text-slate-200 block">
                  Minimal Metadata Mode (Strict Zero-Storage)
                </span>
                <span className="text-[11px] text-slate-400 leading-normal">
                  When enabled, raw incoming message text is never stored to disk. Only an irreversible SHA-256 integrity hash and truncated preview are preserved.
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.privacy_minimal_metadata}
                onChange={(e) => handleChange('privacy_minimal_metadata', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded flex-shrink-0"
              />
            </label>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-rose-300 block">
                  Wipe All Data & Reset All Metrics
                </span>
                <span className="text-[11px] text-slate-400">
                  Permanently wipe all incoming messages, threats, alerts, history, and reset all counters to 0
                </span>
              </div>
              {!confirmClear ? (
                <button
                  type="button"
                  onClick={() => setConfirmClear(true)}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-rose-300 hover:text-white bg-rose-950/60 hover:bg-rose-900 border border-rose-800 transition-colors shadow"
                >
                  Wipe All Data (0 Reset)
                </button>
              ) : (
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => {
                      onClearHistory();
                      setConfirmClear(false);
                    }}
                    className="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                  >
                    Confirm Wipe
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClear(false)}
                    className="px-2.5 py-1 rounded bg-slate-800 text-slate-400 text-xs"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center space-x-2 px-6 py-2.5 rounded-xl font-bold text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-lg shadow-emerald-950/40 disabled:opacity-50"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>Save Preferences</span>
          </button>
        </div>
      </form>

      {/* About Box */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs text-slate-400 flex items-start space-x-3">
        <Info className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
        <div className="space-y-1">
          <h4 className="font-bold text-slate-200">About ScamShield 2.0</h4>
          <p className="leading-relaxed">
            ScamShield — Proactive AI-Powered Incoming Message Scam Detection & Protection Agent.
            Built with modular message connectors, multi-layer heuristic risk scoring, safe URL analysis, and explainable threat rationale.
          </p>
          <div className="pt-1 text-[11px] text-slate-500 font-mono">
            Backend: FastAPI / Python 3.14 • Local Zero-Cloud Resilience Mode Active • Storage: SQLite / Privacy Hashed
          </div>
        </div>
      </div>
    </div>
  );
}
