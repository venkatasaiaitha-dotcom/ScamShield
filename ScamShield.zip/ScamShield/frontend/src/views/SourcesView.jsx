import React, { useState } from 'react';
import {
  Smartphone,
  Mail,
  MessageSquare,
  Globe,
  Cpu,
  CheckCircle2,
  AlertCircle,
  Lock,
  Shield,
  Send,
  Loader2,
  Sparkles,
  Info,
} from 'lucide-react';
import GmailConnectorCard from '../components/GmailConnectorCard';

export default function SourcesView({
  sources,
  onConnectSource,
  onDisconnectSource,
  onSendCustomMessage,
  isSendingCustom,
  onMessageAnalyzed,
  onViewAnalysis,
}) {
  const [customSender, setCustomSender] = useState('SBI-ALERT');
  const [customChannel, setCustomChannel] = useState('SMS');
  const [customText, setCustomText] = useState(
    'Dear Customer, Your account KYC expires today. Verify immediately at http://secure-sbi-portal.top/kyc or your card will be deactivated within 12 hours.'
  );

  const handleCustomSubmit = (e) => {
    e.preventDefault();
    if (!customText.trim()) return;
    onSendCustomMessage({
      source: customChannel,
      sender: customSender.trim() || 'Simulated Sender',
      content: customText.trim(),
    });
  };

  const getSourceIcon = (iconName) => {
    switch (iconName) {
      case 'smartphone':
        return <Smartphone className="w-6 h-6 text-cyan-400" />;
      case 'mail':
        return <Mail className="w-6 h-6 text-rose-400" />;
      case 'message-square':
        return <MessageSquare className="w-6 h-6 text-amber-400" />;
      case 'globe':
        return <Globe className="w-6 h-6 text-teal-400" />;
      default:
        return <Cpu className="w-6 h-6 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Featured Gmail Inspector Card */}
      <GmailConnectorCard
        onMessageAnalyzed={onMessageAnalyzed}
        onOpenDetail={onViewAnalysis}
      />

      {/* Top Section: Connected Sources Management */}
      <div>
        <div className="mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            Connected Message Sources
          </h2>
          <p className="text-xs text-slate-400">
            ScamShield monitors incoming messages from authorized channels. Direct private messaging apps require explicit permission.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sources.map((source) => {
            const isConnected = source.status === 'CONNECTED';
            const isRestricted = source.status === 'RESTRICTED';

            return (
              <div
                key={source.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                  isConnected
                    ? 'bg-slate-900 border-slate-800'
                    : isRestricted
                    ? 'bg-slate-900/60 border-amber-900/40'
                    : 'bg-slate-950/60 border-slate-800/60'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                      {getSourceIcon(source.icon)}
                    </div>
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                        isConnected
                          ? 'bg-emerald-950/80 border-emerald-700/80 text-emerald-300'
                          : isRestricted
                          ? 'bg-amber-950/80 border-amber-700/80 text-amber-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400'
                      }`}
                    >
                      {source.status}
                    </span>
                  </div>

                  <h3 className="mt-3 text-sm font-bold text-white">
                    {source.name}
                  </h3>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                    {source.description}
                  </p>

                  {/* Permission info disclosure (Requirement #1 & #20) */}
                  <div className="mt-3 p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400 flex items-start space-x-2">
                    <Info className="w-3.5 h-3.5 text-slate-500 mt-0.5 flex-shrink-0" />
                    <span>{source.permission_info}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    Checked: <strong className="text-slate-200">{source.message_count}</strong>
                  </span>

                  {isConnected ? (
                    <button
                      onClick={() => onDisconnectSource(source.id)}
                      className="px-3 py-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 border border-slate-700 transition-colors"
                    >
                      Disconnect
                    </button>
                  ) : (
                    <button
                      onClick={() => onConnectSource(source.id)}
                      className="px-3 py-1 rounded-lg font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow"
                    >
                      Connect Channel
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Realistic Interactive Simulator Studio (Requirement #23 & #24) */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-emerald-400">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Interactive Message Simulator Studio
            </h2>
            <p className="text-xs text-slate-400">
              Test how the AI Agent inspects incoming messages in real time with custom sender and text
            </p>
          </div>
        </div>

        <form onSubmit={handleCustomSubmit} className="space-y-4 pt-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Simulated Message Channel
              </label>
              <select
                value={customChannel}
                onChange={(e) => setCustomChannel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="SMS">📱 Android SMS Stream</option>
                <option value="EMAIL">📧 Email Inbox Inbound</option>
                <option value="WEBHOOK">🌐 API / Webhook Feed</option>
                <option value="DEMO">🧪 Demo Channel</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Incoming Sender ID / Number
              </label>
              <input
                type="text"
                value={customSender}
                onChange={(e) => setCustomSender(e.target.value)}
                placeholder="e.g. SBI-ALERT, Amazon, +91-9876543210"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Incoming Message Body
              </label>
              <div className="flex items-center space-x-2 text-[11px] text-slate-400">
                <span>Presets:</span>
                <button
                  type="button"
                  onClick={() => {
                    setCustomSender('SBI-ALERT');
                    setCustomText('Dear Customer, Your SBI account KYC has expired today. Update immediately at http://sbi-kyc-verify-portal.in/login or card blocked.');
                  }}
                  className="text-rose-400 hover:underline"
                >
                  Fake KYC
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => {
                    setCustomSender('UNIV-PORTAL');
                    setCustomText('Your OTP for signing into your student portal is 681042. Valid for 10 minutes. Please do not share this one-time code with anyone.');
                  }}
                  className="text-emerald-400 hover:underline"
                >
                  Legitimate OTP
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => {
                    setCustomSender('+91-98765-43210');
                    setCustomText('Part-Time Job Opportunity! Earn ₹5,000 to ₹10,000 daily by rating movies. Pay ₹499 registration fee on WhatsApp to start.');
                  }}
                  className="text-amber-400 hover:underline"
                >
                  Job Scam
                </button>
              </div>
            </div>
            <textarea
              rows={3}
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="Paste or write any message to simulate an incoming threat..."
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center justify-end">
            <button
              type="submit"
              disabled={isSendingCustom || !customText.trim()}
              className="flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-lg shadow-emerald-950/40 disabled:opacity-50"
            >
              {isSendingCustom ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>ScamShield Analyzing...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Simulate Incoming Message</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Privacy Notice Card (Requirement #19) */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex items-start space-x-3">
        <Lock className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
        <div>
          <h4 className="font-bold text-slate-200">Your Privacy Matters</h4>
          <p className="mt-0.5 leading-relaxed">
            ScamShield analyzes connected messages to identify potential security risks. You control which message sources are connected and can pause protection at any time. Raw message texts can be hashed and minimal metadata preserved according to your privacy settings.
          </p>
        </div>
      </div>
    </div>
  );
}
