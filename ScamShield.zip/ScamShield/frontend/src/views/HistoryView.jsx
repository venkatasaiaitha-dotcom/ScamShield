import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  Trash2,
  Eye,
  Clock,
  Smartphone,
  Mail,
  Cpu,
  Globe,
  RefreshCw,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  XCircle,
} from 'lucide-react';

export default function HistoryView({
  history,
  onSearch,
  onFilterRisk,
  activeRiskFilter,
  searchTerm,
  setSearchTerm,
  onDeleteEntry,
  onClearHistory,
  onViewAnalysis,
  loading,
}) {
  const [confirmClear, setConfirmClear] = useState(false);

  const filterTabs = [
    { id: 'ALL', label: 'All Messages' },
    { id: 'HIGH', label: '🔴 High Risk' },
    { id: 'SUSPICIOUS', label: '🟡 Suspicious' },
    { id: 'LOW', label: '🟢 Low Risk' },
  ];

  const getSourceIcon = (source) => {
    switch (source?.toUpperCase()) {
      case 'SMS':
        return <Smartphone className="w-3.5 h-3.5 text-cyan-400" />;
      case 'EMAIL':
        return <Mail className="w-3.5 h-3.5 text-indigo-400" />;
      case 'WEBHOOK':
        return <Globe className="w-3.5 h-3.5 text-teal-400" />;
      default:
        return <Cpu className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <History className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Protection History
              </h2>
              <p className="text-xs text-slate-400">
                Audit trail of all incoming messages checked by ScamShield
              </p>
            </div>
          </div>

          {/* Privacy Clear All Action */}
          <div>
            {!confirmClear ? (
              <button
                onClick={() => setConfirmClear(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 border border-rose-900/60 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear History</span>
              </button>
            ) : (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-rose-300 font-semibold">Delete all logs?</span>
                <button
                  onClick={() => {
                    onClearHistory();
                    setConfirmClear(false);
                  }}
                  className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                >
                  Confirm
                </button>
                <button
                  onClick={() => setConfirmClear(false)}
                  className="px-2 py-1 rounded bg-slate-800 text-slate-400 text-xs"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pt-2">
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                onSearch(e.target.value);
              }}
              placeholder="Search sender, preview, or category..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-1.5">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => onFilterRisk(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                  activeRiskFilter === tab.id
                    ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* History Items */}
      <div className="space-y-3">
        {history.length > 0 ? (
          history.map((item) => {
            const isHigh = item.risk_level === 'HIGH';
            const isSusp = item.risk_level === 'SUSPICIOUS';
            const riskColor = isHigh ? 'text-rose-400' : isSusp ? 'text-amber-400' : 'text-emerald-400';
            const badgeBg = isHigh ? 'bg-rose-950/60 border-rose-800/80 text-rose-300' : isSusp ? 'bg-amber-950/60 border-amber-800/80 text-amber-300' : 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300';

            return (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-slate-900 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 group"
              >
                <div className="flex items-start space-x-3 flex-1 min-w-0">
                  <div className="mt-1">
                    {isHigh ? (
                      <AlertOctagon className="w-5 h-5 text-rose-400" />
                    ) : isSusp ? (
                      <AlertTriangle className="w-5 h-5 text-amber-400" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${badgeBg}`}>
                        {item.risk_level} RISK
                      </span>
                      <span className="text-xs font-semibold text-slate-200">
                        {item.category?.replace('_', ' ')}
                      </span>
                      <span className="text-slate-500 text-xs">•</span>
                      <span className="flex items-center space-x-1 text-xs text-slate-400">
                        {getSourceIcon(item.source)}
                        <span>{item.sender}</span>
                      </span>
                      <span className="text-slate-500 text-xs">•</span>
                      <span className="flex items-center space-x-1 text-xs text-slate-400">
                        <Clock className="w-3 h-3" />
                        <span>{item.timestamp}</span>
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 font-mono truncate">
                      "{item.content_preview}"
                    </p>
                  </div>
                </div>

                {/* Score & Actions */}
                <div className="flex items-center space-x-3 self-end md:self-center flex-shrink-0">
                  <div className="text-right">
                    <span className={`text-base font-extrabold ${riskColor}`}>
                      {item.risk_score}
                      <span className="text-xs font-normal text-slate-400">/100</span>
                    </span>
                  </div>

                  <button
                    onClick={() => onViewAnalysis(item)}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors border border-slate-700"
                  >
                    <Eye className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Inspect</span>
                  </button>

                  <button
                    onClick={() => onDeleteEntry(item.id)}
                    title="Delete log entry"
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800">
            <History className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-white">No history records match</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms or risk filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
