import React, { useState } from 'react';
import {
  BookOpen,
  KeyRound,
  Link,
  Flame,
  Gift,
  Briefcase,
  Globe2,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';

export default function SafetyView() {
  const [activeTab, setActiveTab] = useState('tips');

  const tips = [
    {
      title: 'Never Share OTPs or Passwords',
      icon: KeyRound,
      color: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
      description:
        'Legitimate banks, government departments, and service providers will NEVER call, text, or email requesting your one-time password or security PIN. Keep them strictly confidential.',
    },
    {
      title: 'Inspect Suspicious Links Carefully',
      icon: Link,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
      description:
        'Fraudsters use look-alike domains like "sbi-kyc-verify.top" or URL shorteners (bit.ly) to mask fake phishing portals. Always navigate directly to the official domain.',
    },
    {
      title: 'Beware of Artificial Urgency Traps',
      icon: Flame,
      color: 'text-orange-400 bg-orange-500/10 border-orange-500/20',
      description:
        'Scammers try to trigger panic with deadlines like "within 24 hours" or "account will be blocked today". Stop, breathe, and verify through an independent channel before clicking.',
    },
    {
      title: 'Don’t Trust Unexpected Rewards or Lotteries',
      icon: Gift,
      color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
      description:
        'If you didn\'t participate in a competition, you haven\'t won a cash prize. Offers asking for a "processing fee" or "tax deposit" to release winnings are 100% scams.',
    },
    {
      title: 'Verify Work-From-Home & Job Offers',
      icon: Briefcase,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
      description:
        'Jobs offering ₹5,000–₹10,000/day for rating videos or typing captchas that demand an upfront registration kit or activation fee are advance-fee frauds.',
    },
    {
      title: 'Authenticate Through Official Mobile Apps',
      icon: Globe2,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      description:
        'Whenever in doubt about a bank card block or KYC notification, open your official bank mobile application or call customer care using the number printed on your physical ATM card.',
    },
  ];

  const comparisons = [
    {
      context: 'Bank KYC Notification',
      scam: {
        sender: 'SBI-ALRT',
        text: 'Your SBI account KYC has expired today. Card will be blocked in 24 hours. Immediately update KYC: http://sbi-kyc-portal.xyz/login',
        flags: ['Artificial urgency (today)', 'Suspicious non-official domain (.xyz)', 'Threat of card blocking'],
      },
      legit: {
        sender: 'SBI-BANK',
        text: 'Dear Customer, Please update your periodic KYC at your nearest SBI home branch or via the official YONO SBI mobile app. SBI never sends links to update KYC.',
        flags: ['Directs to official branch or app', 'Explicitly states bank never sends update links', 'No fake countdown timer'],
      },
    },
    {
      context: 'Authentication One-Time Password (OTP)',
      scam: {
        sender: '+91-98765-43210',
        text: 'Dear customer, your electricity connection will be disconnected tonight at 9 PM. Send the OTP received on SMS to this number to stop disconnection.',
        flags: ['Unverified personal mobile number', 'Demands forwarding the OTP', 'Threatens immediate utility cutoff'],
      },
      legit: {
        sender: 'UNIV-PORTAL',
        text: 'Your OTP for signing into your university portal is 681042. Valid for 10 minutes. Please do not share this one-time code with anyone.',
        flags: ['Explicitly advises "do not share"', 'Informational only', 'No redirection links'],
      },
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header & Mode Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              Stay Safe Online
            </h2>
            <p className="text-xs text-slate-400">
              Essential cybersecurity principles to keep your family and accounts secure
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('tips')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'tips' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Safety Guidelines
          </button>
          <button
            onClick={() => setActiveTab('comparison')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'comparison' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Spot The Scam (Examples)
          </button>
        </div>
      </div>

      {/* Safety Guidelines Cards */}
      {activeTab === 'tips' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tips.map((tip, idx) => {
            const Icon = tip.icon;
            return (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-all shadow-md"
              >
                <div>
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center mb-3.5 ${tip.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-white">
                    {tip.title}
                  </h3>
                  <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                    {tip.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Side-by-Side Scam vs Legit Comparison */}
      {activeTab === 'comparison' && (
        <div className="space-y-6">
          {comparisons.map((item, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Scenario: {item.context}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Scam column */}
                <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/50 space-y-3">
                  <div className="flex items-center justify-between text-xs text-rose-400 font-bold">
                    <span className="flex items-center gap-1.5">
                      <XCircle className="w-4 h-4 text-rose-400" />
                      FRAUDULENT / SCAM MESSAGE
                    </span>
                    <span>Sender: {item.scam.sender}</span>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-slate-200 border border-rose-900/30">
                    "{item.scam.text}"
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-rose-400 block mb-1">
                      Red Flags Identified:
                    </span>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {item.scam.flags.map((flag, fIdx) => (
                        <li key={fIdx} className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                          <span>{flag}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Legit column */}
                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-900/50 space-y-3">
                  <div className="flex items-center justify-between text-xs text-emerald-400 font-bold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      LEGITIMATE NOTIFICATION
                    </span>
                    <span>Sender: {item.legit.sender}</span>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-slate-200 border border-emerald-900/30">
                    "{item.legit.text}"
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-emerald-400 block mb-1">
                      Safety Indicators:
                    </span>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {item.legit.flags.map((flag, fIdx) => (
                        <li key={fIdx} className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>{flag}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
