import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, AlertOctagon, CheckCheck, Eye, Trash2, Clock, CheckCircle } from 'lucide-react';

export default function AlertsView({ alerts, onMarkRead, onMarkAllRead, onViewAnalysis }) {
  const [filterUnread, setFilterUnread] = useState(false);

  const displayedAlerts = filterUnread ? alerts.filter((a) => !a.is_read) : alerts;
  const unreadTotal = alerts.filter((a) => !a.is_read).length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Security Alert Center
              </h2>
              <p className="text-xs text-slate-400">
                Prioritized warnings and adaptive alerts for suspicious incoming messages
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setFilterUnread(!filterUnread)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              filterUnread
                ? 'bg-emerald-950 border-emerald-700 text-emerald-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            {filterUnread ? 'Showing Unread Only' : 'Show All Alerts'}
          </button>

          {unreadTotal > 0 && (
            <button
              onClick={onMarkAllRead}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors border border-slate-700"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Mark All Read</span>
            </button>
          )}
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {displayedAlerts.length > 0 ? (
          displayedAlerts.map((alert) => {
            const isHigh = alert.risk_level === 'HIGH';
            const riskBorder = isHigh ? 'border-rose-500/40' : 'border-amber-500/40';
            const badgeBg = isHigh ? 'bg-rose-950/80 text-rose-300' : 'bg-amber-950/80 text-amber-300';

            return (
              <div
                key={alert.id}
                className={`p-5 rounded-2xl bg-slate-900 border ${riskBorder} transition-all ${
                  !alert.is_read ? 'shadow-lg shadow-rose-950/20' : 'opacity-90'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start space-x-3">
                    <div className="mt-1">
                      {isHigh ? (
                        <AlertOctagon className="w-5 h-5 text-rose-400" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-amber-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${riskBorder} ${badgeBg}`}>
                          {isHigh ? '🔴 HIGH RISK' : '🟡 SUSPICIOUS'}
                        </span>
                        <span className="text-xs font-semibold text-slate-300">
                          {alert.category?.replace('_', ' ')}
                        </span>
                        {!alert.is_read && (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 bg-emerald-500 text-slate-950 rounded-full">
                            NEW
                          </span>
                        )}
                      </div>

                      <h3 className="mt-1.5 text-sm font-semibold text-white leading-snug">
                        {alert.summary}
                      </h3>

                      <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                        <span>Sender: <strong className="text-slate-200">{alert.sender}</strong></span>
                        <span>•</span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{alert.timestamp}</span>
                        </span>
                        <span>•</span>
                        <span>Risk Score: <strong className={isHigh ? 'text-rose-400' : 'text-amber-400'}>{alert.risk_score}/100</strong></span>
                      </div>

                      {alert.reasons_summary && alert.reasons_summary.length > 0 && (
                        <div className="mt-2.5 flex flex-wrap gap-1.5">
                          {alert.reasons_summary.map((rs, idx) => (
                            <span
                              key={idx}
                              className="text-[11px] px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-slate-300"
                            >
                              ⚠ {rs}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Action buttons */}
                  <div className="flex items-center space-x-2 self-end sm:self-center">
                    {!alert.is_read && (
                      <button
                        onClick={() => onMarkRead(alert.id)}
                        className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                        title="Mark as read"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => onViewAnalysis(alert)}
                      className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Analysis</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800">
            <CheckCheck className="w-12 h-12 text-emerald-400/50 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-white">All Clear!</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              {filterUnread
                ? 'No unread security alerts pending. You are up to date.'
                : 'ScamShield has not identified any unresolved threat alerts at this time.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
