import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  ArrowRight,
  Clock,
  Sparkles,
  ExternalLink,
  Smartphone,
  Mail,
  Cpu,
  Globe
} from 'lucide-react';
import ProtectionHero from '../components/ProtectionHero';
import MetricCards from '../components/MetricCards';
import SimulatorQuickBar from '../components/SimulatorQuickBar';
import GmailConnectorCard from '../components/GmailConnectorCard';

export default function DashboardView({
  agentStatus,
  onToggleProtection,
  loadingToggle,
  onTriggerScenario,
  isSimulating,
  recentAnalyses,
  onViewAnalysis,
  onNavigateHistory,
  onMessageAnalyzed,
}) {
  const threatsOnly = (recentAnalyses || []).filter(
    (a) => a.risk_level === 'HIGH' || a.risk_level === 'SUSPICIOUS'
  );

  const getSourceIcon = (source) => {
    switch (source?.toUpperCase()) {
      case 'SMS':
        return <Smartphone className="w-3.5 h-3.5 text-cyan-400" />;
      case 'EMAIL':
      case 'GMAIL':
        return <Mail className="w-3.5 h-3.5 text-rose-400" />;
      case 'WEBHOOK':
        return <Globe className="w-3.5 h-3.5 text-teal-400" />;
      default:
        return <Cpu className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Primary Protection Hero Section */}
      <ProtectionHero
        agentStatus={agentStatus}
        onToggleProtection={onToggleProtection}
        loadingToggle={loadingToggle}
      />

      {/* Main KPI Statistics */}
      <MetricCards stats={agentStatus} />

      {/* Gmail Input & Inbound Safety Inspector */}
      <GmailConnectorCard
        onMessageAnalyzed={onMessageAnalyzed}
        onOpenDetail={onViewAnalysis}
      />

      {/* Quick Interactive Simulator Trigger Bar */}
      <SimulatorQuickBar
        onTriggerScenario={onTriggerScenario}
        isSimulating={isSimulating}
      />

      {/* 2-Column Split: Recent Threats & Live Protection Activity Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Threats Card (Requirement #7 & #8) */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <h3 className="text-sm font-bold tracking-wide text-white uppercase">
                Recent Threats Detected
              </h3>
            </div>
            <button
              onClick={onNavigateHistory}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center space-x-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="mt-4 space-y-3 flex-1">
            {threatsOnly.length > 0 ? (
              threatsOnly.slice(0, 4).map((threat) => {
                const isHigh = threat.risk_level === 'HIGH';
                return (
                  <div
                    key={threat.id}
                    onClick={() => onViewAnalysis(threat)}
                    className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center space-x-1.5">
                        <span className={`w-2 h-2 rounded-full ${isHigh ? 'bg-rose-400' : 'bg-amber-400'}`} />
                        <span className={`font-bold ${isHigh ? 'text-rose-400' : 'text-amber-400'}`}>
                          {isHigh ? '🔴 HIGH RISK' : '🟡 SUSPICIOUS'}
                        </span>
                        <span className="text-slate-400">• {threat.category?.replace('_', ' ')}</span>
                      </div>
                      <span className={`font-mono font-bold text-xs ${isHigh ? 'text-rose-400' : 'text-amber-400'}`}>
                        {threat.risk_score}/100
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-1 italic group-hover:text-white transition-colors">
                      "{threat.content_preview}"
                    </p>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center space-x-1">
                        {getSourceIcon(threat.source)}
                        <span>{threat.sender}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{threat.timestamp}</span>
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="h-44 flex flex-col items-center justify-center text-center p-4 border border-dashed border-slate-800 rounded-xl">
                <ShieldCheck className="w-8 h-8 text-emerald-400/60 mb-2" />
                <p className="text-xs font-semibold text-slate-300">No active threats detected</p>
                <p className="text-[11px] text-slate-400 mt-0.5 max-w-xs">
                  All recently inspected incoming messages have passed safety checks.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Protection Activity Timeline (Requirement #8: 10:42 AM 🔴 Phishing, 10:31 AM 🟡 Job scam, 10:12 AM 🟢 Normal delivery) */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold tracking-wide text-white uppercase">
                Protection Activity Timeline
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">
              Live automated feed
            </span>
          </div>

          <div className="mt-4 space-y-3.5 flex-1 overflow-y-auto max-h-[340px] pr-1">
            {(recentAnalyses || []).length > 0 ? (
              recentAnalyses.slice(0, 6).map((item) => {
                const isHigh = item.risk_level === 'HIGH';
                const isSusp = item.risk_level === 'SUSPICIOUS';

                return (
                  <div
                    key={item.id}
                    onClick={() => onViewAnalysis(item)}
                    className="flex items-start space-x-3 text-xs p-2 rounded-lg hover:bg-slate-950/60 transition-colors cursor-pointer group"
                  >
                    <div className="mt-0.5 flex-shrink-0">
                      {isHigh ? (
                        <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-rose-950/80 text-rose-400 font-bold text-[10px] border border-rose-800">
                          🔴
                        </span>
                      ) : isSusp ? (
                        <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-amber-950/80 text-amber-400 font-bold text-[10px] border border-amber-800">
                          🟡
                        </span>
                      ) : (
                        <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-950/80 text-emerald-400 font-bold text-[10px] border border-emerald-800">
                          🟢
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200 truncate group-hover:text-emerald-300 transition-colors">
                          {isHigh
                            ? `${item.category?.replace('_', ' ')} Phishing Attempt`
                            : isSusp
                            ? `Suspicious ${item.category?.replace('_', ' ')} Pattern`
                            : `Normal ${item.category?.replace('_', ' ')} Verified`}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono flex-shrink-0 ml-2">
                          {item.timestamp}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {item.sender}: {item.content_preview}
                      </p>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="h-44 flex flex-col items-center justify-center text-center p-4">
                <Clock className="w-8 h-8 text-slate-600 mb-2" />
                <p className="text-xs text-slate-400">Waiting for incoming messages...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
