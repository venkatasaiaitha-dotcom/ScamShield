import React from 'react';
import { Shield, ShieldAlert, ShieldCheck, Power, RefreshCw, Smartphone, Mail, Globe, Cpu } from 'lucide-react';

export default function ProtectionHero({ agentStatus, onToggleProtection, loadingToggle }) {
  const isActive = agentStatus?.protection_active;
  const monitoringSources = agentStatus?.monitoring_sources || [];

  return (
    <div className={`relative overflow-hidden rounded-2xl border transition-all duration-300 p-6 md:p-8 shadow-xl ${
      isActive
        ? 'bg-gradient-to-br from-slate-900 via-slate-900/90 to-emerald-950/40 border-emerald-800/60 shadow-emerald-950/20'
        : 'bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 border-slate-800 shadow-slate-950/40'
    }`}>
      {/* Background glow effects */}
      <div className={`absolute -right-16 -top-16 w-64 h-64 rounded-full blur-3xl pointer-events-none transition-opacity duration-700 ${
        isActive ? 'bg-emerald-500/10 opacity-100' : 'bg-slate-700/10 opacity-40'
      }`} />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        {/* Left Column: Heading and explanation */}
        <div className="space-y-4 max-w-2xl">
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center border shadow-inner ${
              isActive
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}>
              <Shield className={`w-6 h-6 ${isActive ? 'animate-pulse-slow' : ''}`} />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-2">
                🛡️ ScamShield
              </h1>
              <p className="text-sm font-medium text-emerald-400">
                Your AI Safety Agent
              </p>
            </div>
          </div>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            ScamShield automatically inspects incoming messages as they arrive across connected sources and warns you before you interact with them.
          </p>

          {/* Status Display */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <div className={`inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full text-xs font-semibold border ${
              isActive
                ? 'bg-emerald-950/80 border-emerald-700/80 text-emerald-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-300'
            }`}>
              <span className={`w-2.5 h-2.5 rounded-full ${isActive ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
              <span>{isActive ? '🟢 Protection Active' : '⚪ Protection Paused'}</span>
            </div>

            <span className="text-xs text-slate-400">
              {isActive
                ? 'Monitoring connected message sources'
                : 'Turn protection on to automatically analyze incoming messages'}
            </span>
          </div>

          {/* Connected message sources pills */}
          {isActive && monitoringSources.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-xs text-slate-400 font-medium">Active Channels:</span>
              {monitoringSources.map((sourceName) => (
                <span
                  key={sourceName}
                  className="inline-flex items-center text-[11px] px-2.5 py-1 rounded-md bg-slate-800/90 text-slate-300 border border-slate-700/70"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5" />
                  {sourceName}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Large Action Switch */}
        <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end justify-center gap-3 pt-2 lg:pt-0">
          <button
            onClick={onToggleProtection}
            disabled={loadingToggle}
            className={`flex items-center justify-center space-x-3 px-6 py-3.5 rounded-xl font-bold text-sm tracking-wide transition-all shadow-lg active:scale-95 disabled:opacity-50 ${
              isActive
                ? 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 hover:border-slate-600 shadow-slate-950/60'
                : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-500/20'
            }`}
          >
            {loadingToggle ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Power className="w-5 h-5" />
            )}
            <span>{isActive ? 'Pause Protection' : 'Enable Protection'}</span>
          </button>

          <span className="text-[11px] text-slate-400">
            {isActive ? 'Click to temporarily halt incoming analysis' : 'Proactive safety agent is standing by'}
          </span>
        </div>
      </div>
    </div>
  );
}
