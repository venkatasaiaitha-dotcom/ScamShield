import React from 'react';
import { MailCheck, ShieldAlert, AlertTriangle, AlertOctagon } from 'lucide-react';

export default function MetricCards({ stats }) {
  const cards = [
    {
      title: 'Messages Checked',
      value: stats?.messages_checked ?? 247,
      label: 'Inspected automatically',
      icon: MailCheck,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/20',
    },
    {
      title: 'Threats Detected',
      value: stats?.threats_detected ?? 8,
      label: 'Total flagged interactions',
      icon: ShieldAlert,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/20',
    },
    {
      title: 'High Risk',
      value: stats?.high_risk_count ?? 5,
      label: 'Dangerous scam threats',
      icon: AlertOctagon,
      color: 'text-rose-400',
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/20',
    },
    {
      title: 'Suspicious',
      value: stats?.suspicious_count ?? 3,
      label: 'Caution required',
      icon: AlertTriangle,
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10',
      border: 'border-yellow-500/20',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className={`p-4 sm:p-5 rounded-xl bg-slate-900/90 border ${card.border} backdrop-blur-sm transition-all hover:translate-y-[-2px] hover:shadow-lg`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs sm:text-sm font-medium text-slate-400">
                {card.title}
              </span>
              <div className={`p-2 rounded-lg ${card.bg} ${card.color}`}>
                <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline space-x-2">
              <span className={`text-2xl sm:text-3xl font-extrabold tracking-tight ${card.color}`}>
                {card.value.toLocaleString()}
              </span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">
              {card.label}
            </p>
          </div>
        );
      })}
    </div>
  );
}
