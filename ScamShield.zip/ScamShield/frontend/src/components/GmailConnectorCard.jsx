import React, { useState, useEffect } from 'react';
import {
  Mail,
  RefreshCw,
  Send,
  Lock,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  HelpCircle,
  X,
  Sparkles,
  Inbox,
  KeyRound,
  ShieldCheck,
  Check,
  ArrowRight,
} from 'lucide-react';
import { api } from '../services/api';

export default function GmailConnectorCard({ onMessageAnalyzed, onOpenDetail }) {
  const [activeTab, setActiveTab] = useState('input'); // 'input' or 'sync'
  const [gmailStatus, setGmailStatus] = useState({ connected: false, email: '', last_sync: '' });

  // Direct Input Form State
  const [sender, setSender] = useState('Google Security <no-reply@security-google-auth.com>');
  const [subject, setSubject] = useState('Critical Alert: Unauthorized sign-in attempt blocked');
  const [body, setBody] = useState(
    'We detected an unusual sign-in attempt to your Google Account from Moscow, Russia. If this was not you, verify your identity and update your password immediately at: http://google-security-verify.xyz/auth or your account will be permanently suspended within 24 hours.'
  );
  const [loadingInput, setLoadingInput] = useState(false);

  // Live Sync Form State
  const [gmailEmail, setGmailEmail] = useState('');
  const [appPassword, setAppPassword] = useState('');
  const [loadingConnect, setLoadingConnect] = useState(false);
  const [loadingSync, setLoadingSync] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [feedback, setFeedback] = useState(null); // { type: 'success' | 'error', message: '' }

  useEffect(() => {
    loadGmailStatus();
  }, []);

  const loadGmailStatus = async () => {
    try {
      const status = await api.getGmailStatus();
      setGmailStatus(status);
      if (status.email) {
        setGmailEmail(status.email);
      }
    } catch (err) {
      console.error('Error loading Gmail status:', err);
    }
  };

  // Direct Ingest Submit
  const handleDirectInspect = async (e) => {
    e.preventDefault();
    if (!body.trim()) return;

    setLoadingInput(true);
    setFeedback(null);
    try {
      const res = await api.inputGmailMessage({
        sender: sender.trim() || 'Unknown Gmail Sender',
        subject: subject.trim() || '(No Subject)',
        body: body.trim(),
      });

      if (onMessageAnalyzed) onMessageAnalyzed(res);
      setFeedback({
        type: 'success',
        message: `Gmail message inspected! Result: ${res.risk_level} RISK (Score: ${res.risk_score}/100)`,
        analysis: res,
      });
    } catch (err) {
      setFeedback({ type: 'error', message: err.message || 'Failed to inspect message' });
    } finally {
      setLoadingInput(false);
    }
  };

  // Live Gmail Connect
  const handleConnectGmail = async (e) => {
    e.preventDefault();
    if (!gmailEmail.trim() || !appPassword.trim()) {
      setFeedback({ type: 'error', message: 'Please provide both your Gmail address and 16-character App Password.' });
      return;
    }

    setLoadingConnect(true);
    setFeedback(null);
    try {
      const res = await api.connectGmail(gmailEmail.trim(), appPassword.trim());
      await loadGmailStatus();
      setAppPassword('');
      setFeedback({ type: 'success', message: res.message });
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setLoadingConnect(false);
    }
  };

  const handleDisconnectGmail = async () => {
    try {
      await api.disconnectGmail();
      await loadGmailStatus();
      setFeedback({ type: 'success', message: 'Gmail account disconnected.' });
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    }
  };

  // Live Gmail Sync
  const handleSyncGmail = async () => {
    setLoadingSync(true);
    setFeedback(null);
    try {
      const res = await api.syncGmail();
      await loadGmailStatus();
      if (res.analyses && res.analyses.length > 0) {
        res.analyses.forEach((a) => {
          if (onMessageAnalyzed) onMessageAnalyzed(a);
        });
      }
      setFeedback({
        type: 'success',
        message: res.message,
      });
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setLoadingSync(false);
    }
  };

  const samplePresets = [
    {
      label: 'Google Account Phishing',
      sender: 'Google Security <no-reply@security-google-auth.com>',
      subject: 'Critical Alert: Unauthorized sign-in attempt blocked',
      body: 'We detected an unusual sign-in attempt to your Google Account from Moscow, Russia. If this was not you, verify your identity and update your password immediately at: http://google-security-verify.xyz/auth or your account will be permanently suspended within 24 hours.',
    },
    {
      label: 'Fake Wire Transfer Scam',
      sender: 'PayPal Service <accounting@paypal-instant-invoices.top>',
      subject: 'Payment Confirmation: $1,499.00 USD authorized',
      body: 'Thank you for your business. Your debit of $1,499.00 to CryptoTrade LLC is being processed. If you did not make this purchase, call PayPal Fraud Resolution immediately at +1-888-555-0144 or dispute charges at http://paypal-resolution-center.online/cancel',
    },
    {
      label: 'DHL Courier Fee Phishing',
      sender: 'DHL Express <tracking@dhl-delivery-clearance.club>',
      subject: 'Shipment #DHL98421: Custom duty fee payment required',
      body: 'Your international parcel has arrived at the regional hub but cannot be delivered due to an outstanding customs clearance fee of $3.50. Pay immediately within 48 hours to avoid package return: http://dhl-clearance-portal.site/pay',
    },
    {
      label: 'Legitimate Gmail Newsletter (Safe)',
      sender: 'GitHub <notifications@github.com>',
      subject: '[GitHub] A personal access token has been generated',
      body: 'Hi, you recently created a new personal access token on GitHub with repository read access. If you did not create this token, please revoke it immediately in your account settings at https://github.com/settings/tokens. Thank you.',
    },
  ];

  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
      {/* Header */}
      <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/70 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-red-500/20 via-rose-500/20 to-amber-500/20 border border-red-500/30 flex items-center justify-center text-red-400 shadow-inner">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                Gmail Inbound Safety Inspector
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-950/80 text-red-300 border border-red-800/80 uppercase">
                Active Source
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Inspect incoming emails from Gmail directly or sync live messages via IMAP SSL
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('input')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'input'
                ? 'bg-red-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Direct Gmail Input
          </button>
          <button
            onClick={() => setActiveTab('sync')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
              activeTab === 'sync'
                ? 'bg-red-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Live Account Sync</span>
            {gmailStatus.connected && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`p-3.5 mx-6 mt-4 rounded-xl text-xs flex items-center justify-between border ${
            feedback.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-800 text-emerald-200'
              : 'bg-rose-950/70 border-rose-800 text-rose-200'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>

          {feedback.analysis && (
            <button
              onClick={() => onOpenDetail && onOpenDetail(feedback.analysis)}
              className="text-xs font-bold text-emerald-300 underline hover:text-emerald-100 flex items-center gap-1"
            >
              <span>View Full Report</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* TAB 1: Direct Gmail Input (Inspect any Gmail message) */}
      {activeTab === 'input' && (
        <form onSubmit={handleDirectInspect} className="p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wide">
              Quick Test Presets:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {samplePresets.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setSender(p.sender);
                    setSubject(p.subject);
                    setBody(p.body);
                  }}
                  className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                From (Sender Email / Name)
              </label>
              <input
                type="text"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                placeholder="e.g. security@bank-alerts.com"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Email Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Action Required: Your account will be closed"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Email Content / Body
            </label>
            <textarea
              rows={4}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Paste the body text or HTML of any email received in your Gmail..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-red-500 leading-relaxed"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-400">
              ScamShield will extract all links, analyze domain signatures, and score risk
            </span>

            <button
              type="submit"
              disabled={loadingInput || !body.trim()}
              className="flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-red-600 hover:bg-red-500 text-white transition-all shadow-lg shadow-red-950/40 active:scale-95 disabled:opacity-50"
            >
              {loadingInput ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Inspecting Gmail...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Inspect Gmail Message</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: Live Account Sync (Real IMAP SSL) */}
      {activeTab === 'sync' && (
        <div className="p-5 sm:p-6 space-y-5">
          {/* Connection status card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${gmailStatus.connected ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                {gmailStatus.connected ? <ShieldCheck className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-white">
                    {gmailStatus.connected ? 'Live Gmail Sync Active' : 'Gmail Not Connected'}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    gmailStatus.connected ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {gmailStatus.connected ? 'CONNECTED' : 'DISCONNECTED'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {gmailStatus.connected
                    ? `Monitoring ${gmailStatus.masked_email || gmailStatus.email} via secure IMAP SSL (imap.gmail.com:993)`
                    : 'Connect your Gmail account to automatically inspect new incoming emails as they arrive'}
                </p>
              </div>
            </div>

            {gmailStatus.connected ? (
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleSyncGmail}
                  disabled={loadingSync}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingSync ? 'animate-spin' : ''}`} />
                  <span>{loadingSync ? 'Scanning Inbox...' : 'Sync Unread Emails'}</span>
                </button>
                <button
                  onClick={handleDisconnectGmail}
                  className="px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-slate-800 border border-slate-800 transition-colors"
                >
                  Disconnect
                </button>
              </div>
            ) : null}
          </div>

          {/* Connect credentials form */}
          {!gmailStatus.connected && (
            <form onSubmit={handleConnectGmail} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Your Gmail Address
                  </label>
                  <input
                    type="email"
                    value={gmailEmail}
                    onChange={(e) => setGmailEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-300">
                      16-Character Google App Password
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowHelp(true)}
                      className="text-[11px] text-red-400 hover:underline flex items-center gap-1"
                    >
                      <HelpCircle className="w-3 h-3" />
                      <span>How to get this?</span>
                    </button>
                  </div>
                  <input
                    type="password"
                    value={appPassword}
                    onChange={(e) => setAppPassword(e.target.value)}
                    placeholder="xxxx xxxx xxxx xxxx"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  Credentials are encrypted in memory; normal passwords cannot be used.
                </span>

                <button
                  type="submit"
                  disabled={loadingConnect || !gmailEmail.trim() || !appPassword.trim()}
                  className="flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-red-600 hover:bg-red-500 text-white transition-all shadow-md shadow-red-950/40 disabled:opacity-50"
                >
                  {loadingConnect ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Authenticating with Google...</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="w-4 h-4" />
                      <span>Connect Gmail Account</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* Help Modal Guide */}
          {showHelp && (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  How to generate a 16-character Google App Password (Takes 30 seconds)
                </h4>
                <button onClick={() => setShowHelp(false)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300">
                <li>Go to your Google Account at <a href="https://myaccount.google.com/security" target="_blank" rel="noreferrer" className="text-cyan-400 underline">myaccount.google.com/security</a></li>
                <li>Make sure <strong>2-Step Verification</strong> is turned ON.</li>
                <li>Search for <strong>"App passwords"</strong> or visit <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer" className="text-cyan-400 underline">myaccount.google.com/apppasswords</a></li>
                <li>Type "ScamShield" as the app name and click <strong>Create</strong>.</li>
                <li>Copy the 16-character code (e.g. <code className="text-amber-300 font-mono">abcd efgh ijkl mnop</code>) and paste it above!</li>
              </ol>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
