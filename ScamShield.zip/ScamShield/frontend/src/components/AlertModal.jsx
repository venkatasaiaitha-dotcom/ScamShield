import React from 'react';
import { ShieldAlert, AlertTriangle, AlertOctagon, X, ExternalLink, ShieldCheck, Eye } from 'lucide-react';

export default function AlertModal({ alert, onClose, onViewDetails }) {
  if (!alert) return null;

  const isHighRisk = alert.risk_level === 'HIGH' || alert.risk_score >= 70;
  const riskColor = isHighRisk ? 'text-rose-400' : 'text-amber-400';
  const borderColor = isHighRisk ? 'border-rose-500/50' : 'border-amber-500/50';
  const badgeBg = isHighRisk ? 'bg-rose-950/80 text-rose-300' : 'bg-amber-950/80 text-amber-300';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-2xl bg-slate-900 border ${borderColor} shadow-2xl p-6 relative overflow-hidden`}>
        {/* Subtle top indicator bar */}
        <div className={`absolute top-0 left-0 right-0 h-1.5 ${isHighRisk ? 'bg-rose-500' : 'bg-amber-500'}`} />

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 rounded-xl border ${borderColor} ${badgeBg}`}>
              {isHighRisk ? (
                <AlertOctagon className="w-6 h-6 text-rose-400 animate-pulse" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-amber-400" />
              )}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold tracking-wider uppercase text-slate-400">
                  🛡️ ScamShield Alert
                </span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${borderColor} ${badgeBg}`}>
                  {isHighRisk ? '⚠️ HIGH-RISK MESSAGE' : '⚠️ SUSPICIOUS MESSAGE'}
                </span>
              </div>
              <div className="text-xl font-extrabold text-white mt-0.5">
                Risk Score: <span className={riskColor}>{alert.risk_score}/100</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message preview snippet */}
        <div className="mt-4 p-3 rounded-lg bg-slate-950/80 border border-slate-800/80">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span>From: <strong className="text-slate-200">{alert.sender}</strong></span>
            <span>{alert.source || 'Incoming'}</span>
          </div>
          <p className="text-xs text-slate-300 italic line-clamp-2">
            "{alert.content_preview || alert.summary}"
          </p>
        </div>

        {/* Human summary */}
        <p className="mt-3 text-sm text-slate-200 leading-relaxed font-medium">
          {alert.summary || 'This incoming message contains characteristics commonly associated with scam attempts.'}
        </p>

        {/* Reasons bullets */}
        {alert.reasons && alert.reasons.length > 0 && (
          <div className="mt-3 space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Why did ScamShield warn me?
            </span>
            <ul className="space-y-1">
              {alert.reasons.slice(0, 3).map((r, i) => (
                <li key={i} className="text-xs text-slate-300 flex items-start space-x-2">
                  <span className={`mt-1 w-1.5 h-1.5 rounded-full ${isHighRisk ? 'bg-rose-400' : 'bg-amber-400'}`} />
                  <span>
                    <strong className="text-white">{r.title || r}:</strong> {r.description || ''}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Action Center - Don'ts & Dos */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-lg bg-rose-950/20 border border-rose-900/30 text-rose-200">
            <span className="font-bold flex items-center gap-1 text-rose-400 mb-1">
              ❌ What NOT to do
            </span>
            <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-300">
              <li>Do not click any links</li>
              <li>Do not share OTP or PIN</li>
            </ul>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-900/30 text-emerald-200">
            <span className="font-bold flex items-center gap-1 text-emerald-400 mb-1">
              ✅ Recommended Action
            </span>
            <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-300">
              <li>Verify on official app</li>
              <li>Contact bank independently</li>
            </ul>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="mt-5 flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Dismiss Warning
          </button>
          <button
            onClick={() => {
              onClose();
              onViewDetails(alert);
            }}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-md shadow-emerald-950/40"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>View Full Analysis</span>
          </button>
        </div>
      </div>
    </div>
  );
}
