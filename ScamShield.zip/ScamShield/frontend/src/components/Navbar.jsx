import React from 'react';
import { Shield, ShieldAlert, ShieldCheck, Bell, Volume2, VolumeX, Radio, Wifi, WifiOff } from 'lucide-react';

export default function Navbar({
  agentStatus,
  wsConnected,
  unreadCount,
  soundEnabled,
  setSoundEnabled,
  currentTab,
  setCurrentTab,
  onOpenAlerts,
}) {
  const isProtectionActive = agentStatus?.protection_active;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand identity */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentTab('home')}>
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-cyan-500 shadow-lg shadow-emerald-950/40">
            <Shield className="w-5 h-5 text-white" />
            {isProtectionActive && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-lg tracking-tight text-white flex items-center">
                Scam<span className="text-emerald-400">Shield</span>
              </span>
              <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-800/60">
                AI Agent
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Detect. Understand. Stay Safe.
            </p>
          </div>
        </div>

        {/* Center Desktop Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1 bg-slate-900/90 border border-slate-800/80 rounded-full px-2 py-1 shadow-inner">
          {[
            { id: 'home', label: 'Home' },
            { id: 'alerts', label: 'Alerts', badge: unreadCount },
            { id: 'history', label: 'History' },
            { id: 'sources', label: 'Sources & Simulator' },
            { id: 'safety', label: 'Safety Hub' },
            { id: 'settings', label: 'Settings' },
          ].map((tab) => {
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id)}
                className={`relative px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {tab.label}
                {tab.badge > 0 && (
                  <span className={`ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                    isActive ? 'bg-slate-950 text-emerald-300' : 'bg-rose-500 text-white'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Actions & Status Badges */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Live WS Pulse */}
          <div
            title={wsConnected ? 'Real-Time Live Feed Connected' : 'Reconnecting Live Stream...'}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-300"
          >
            <Radio className={`w-3.5 h-3.5 ${wsConnected ? 'text-emerald-400 animate-pulse' : 'text-amber-400'}`} />
            <span className="hidden lg:inline">{wsConnected ? 'Live' : 'Syncing'}</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'Mute alert chimes' : 'Unmute alert chimes'}
            className={`p-2 rounded-lg border transition-colors ${
              soundEnabled
                ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                : 'bg-slate-900/40 border-slate-800/40 text-slate-500'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Unread Alert Bell */}
          <button
            onClick={onOpenAlerts}
            title="View Security Alerts"
            className="relative p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {/* Status Badge */}
          <div className={`hidden sm:flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
            isProtectionActive
              ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
              : 'bg-slate-900 border-slate-700 text-slate-400'
          }`}>
            <span className={`w-2 h-2 rounded-full ${isProtectionActive ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`}></span>
            <span>{isProtectionActive ? 'Protection Active' : 'Protection Paused'}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
