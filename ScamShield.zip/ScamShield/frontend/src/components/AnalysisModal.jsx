import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  X,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Link,
  Lock,
  LockOpen,
  CheckCircle2,
  XCircle,
  FileText,
  Copy,
  Check,
} from 'lucide-react';

export default function AnalysisModal({ analysis, onClose }) {
  const [showTechnical, setShowTechnical] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!analysis) return null;

  const isHighRisk = analysis.risk_level === 'HIGH' || analysis.risk_score >= 70;
  const isSuspicious = analysis.risk_level === 'SUSPICIOUS' || (analysis.risk_score >= 30 && analysis.risk_score < 70);
  const isLow = !isHighRisk && !isSuspicious;

  const riskColor = isHighRisk ? 'text-rose-400' : isSuspicious ? 'text-amber-400' : 'text-emerald-400';
  const badgeBorder = isHighRisk ? 'border-rose-500/50' : isSuspicious ? 'border-amber-500/50' : 'border-emerald-500/50';
  const badgeBg = isHighRisk ? 'bg-rose-950/80 text-rose-300' : isSuspicious ? 'bg-amber-950/80 text-amber-300' : 'bg-emerald-950/80 text-emerald-300';

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(analysis, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-xl border ${badgeBorder} ${badgeBg}`}>
              {isHighRisk ? (
                <AlertOctagon className="w-6 h-6" />
              ) : isSuspicious ? (
                <AlertTriangle className="w-6 h-6" />
              ) : (
                <ShieldCheck className="w-6 h-6" />
              )}
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                SCAMSHIELD ANALYSIS
              </h2>
              <p className="text-xs text-slate-400">
                Processed at {analysis.timestamp || 'Just now'} • Source: <strong className="text-slate-200">{analysis.source || 'SIMULATOR'}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              title="Copy JSON metadata"
              className="p-1.5 rounded-lg border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* Key Metric Gauges */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 text-center">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Risk Score
              </span>
              <span className={`text-2xl sm:text-3xl font-black ${riskColor}`}>
                {analysis.risk_score}
                <span className="text-xs font-normal text-slate-400"> / 100</span>
              </span>
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Threat Level
              </span>
              <span className={`inline-block mt-1 text-xs font-bold px-2.5 py-0.5 rounded-full border ${badgeBorder} ${badgeBg}`}>
                {analysis.risk_level} RISK
              </span>
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Category
              </span>
              <span className="inline-block mt-1 text-xs font-bold text-slate-200 uppercase tracking-wide">
                {analysis.category ? analysis.category.replace('_', ' ') : 'GENERAL'}
              </span>
            </div>
          </div>

          {/* Message Content Preview */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Message Preview (Sender: <span className="text-slate-200">{analysis.sender}</span>)
            </span>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/90 text-xs sm:text-sm text-slate-200 leading-relaxed font-mono select-all">
              {analysis.content_preview || analysis.full_content || 'No text content available'}
            </div>
          </div>

          {/* Human Readable Summary */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Executive Summary
            </span>
            <p className="text-sm text-slate-300 leading-relaxed bg-slate-800/40 p-3.5 rounded-xl border border-slate-800/60">
              {analysis.summary}
            </p>
          </div>

          {/* Why? Reasons Breakdown */}
          {analysis.reasons && analysis.reasons.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">
                Why Did ScamShield Flag This?
              </span>
              <div className="grid gap-2.5">
                {analysis.reasons.map((reason, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start space-x-3"
                  >
                    <div className="mt-0.5">
                      {reason.severity === 'HIGH' ? (
                        <XCircle className="w-4 h-4 text-rose-400" />
                      ) : reason.severity === 'LOW' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">
                        {reason.title}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5 leading-normal">
                        {reason.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Center - Don'ts & Dos */}
          {analysis.recommendations && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40">
                <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block mb-2">
                  ❌ What NOT to do
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {analysis.recommendations.donts?.map((d, i) => (
                    <li key={i} className="flex items-start space-x-1.5">
                      <span className="text-rose-400 font-bold">•</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-900/40">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block mb-2">
                  ✅ Recommended Next Steps
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {analysis.recommendations.dos?.map((d, i) => (
                    <li key={i} className="flex items-start space-x-1.5">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Collapsible Technical Details */}
          <div className="border border-slate-800 rounded-xl overflow-hidden">
            <button
              onClick={() => setShowTechnical(!showTechnical)}
              className="w-full p-3.5 bg-slate-950/60 hover:bg-slate-950 flex items-center justify-between text-xs font-bold text-slate-300 transition-colors"
            >
              <span>🔬 Technical Inspection Details & URL Signals</span>
              {showTechnical ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showTechnical && (
              <div className="p-4 bg-slate-950/90 border-t border-slate-800/80 space-y-4 text-xs">
                {/* URLs Detected */}
                <div>
                  <span className="font-semibold text-slate-400 block mb-2">
                    Extracted Hyperlinks ({analysis.urls_detected?.length || 0}):
                  </span>
                  {analysis.urls_detected && analysis.urls_detected.length > 0 ? (
                    <div className="space-y-2">
                      {analysis.urls_detected.map((u, i) => (
                        <div key={i} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-[11px] text-cyan-300 truncate max-w-sm">
                              {u.url}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                              Risk +{u.risk_contribution}
                            </span>
                          </div>
                          <div className="mt-1 flex flex-wrap gap-1.5 text-[10px]">
                            <span className={`px-1.5 py-0.5 rounded ${u.is_https ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                              {u.is_https ? 'HTTPS Valid' : 'Insecure HTTP'}
                            </span>
                            {u.is_shortener && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300">
                                Shortener Mask
                              </span>
                            )}
                            {u.is_ip_address && (
                              <span className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 font-bold">
                                Raw IP Host
                              </span>
                            )}
                            {u.is_lookalike && (
                              <span className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 font-bold">
                                Brand Lookalike
                              </span>
                            )}
                          </div>
                          {u.suspicious_flags && u.suspicious_flags.length > 0 && (
                            <ul className="mt-2 space-y-0.5 text-[10px] text-slate-400">
                              {u.suspicious_flags.map((f, fi) => (
                                <li key={fi}>⚠ {f}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 italic">No URLs found in message content.</p>
                  )}
                </div>

                {/* Signals Map */}
                {analysis.technical_details && (
                  <div>
                    <span className="font-semibold text-slate-400 block mb-1">
                      Signal Vectors:
                    </span>
                    <pre className="p-3 rounded-lg bg-slate-900 text-slate-300 font-mono text-[11px] overflow-x-auto">
                      {JSON.stringify(analysis.technical_details, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors"
          >
            Close Analysis
          </button>
        </div>
      </div>
    </div>
  );
}
