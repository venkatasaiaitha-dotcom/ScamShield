import React, { useState } from 'react';
import { Play, Sparkles, CheckCircle2, AlertTriangle, AlertOctagon, HelpCircle, Loader2 } from 'lucide-react';

export default function SimulatorQuickBar({ onTriggerScenario, isSimulating }) {
  const [activeScenario, setActiveScenario] = useState(null);

  const presets = [
    { type: 'FAKE_KYC', label: 'Fake KYC', icon: AlertOctagon, color: 'border-rose-500/50 text-rose-300 hover:bg-rose-950/40' },
    { type: 'BANK_IMPERSONATION', label: 'Bank Phishing', icon: AlertOctagon, color: 'border-rose-500/50 text-rose-300 hover:bg-rose-950/40' },
    { type: 'JOB_SCAM', label: 'Job Scam', icon: AlertTriangle, color: 'border-amber-500/50 text-amber-300 hover:bg-amber-950/40' },
    { type: 'PRIZE_SCAM', label: 'Prize / Lottery', icon: AlertTriangle, color: 'border-amber-500/50 text-amber-300 hover:bg-amber-950/40' },
    { type: 'LEGITIMATE_OTP', label: 'Legitimate OTP (Test Safe)', icon: CheckCircle2, color: 'border-emerald-500/50 text-emerald-300 hover:bg-emerald-950/40' },
    { type: 'NORMAL_DELIVERY', label: 'Normal Delivery', icon: CheckCircle2, color: 'border-emerald-500/50 text-emerald-300 hover:bg-emerald-950/40' },
  ];

  const handleSimulate = async (type) => {
    setActiveScenario(type);
    await onTriggerScenario(type);
    setActiveScenario(null);
  };

  return (
    <div className="p-4 sm:p-5 rounded-xl bg-slate-900/80 border border-slate-800 shadow-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold text-white tracking-wide uppercase">
            Incoming Message Simulator (Live Demo Stream)
          </h2>
        </div>
        <span className="text-[11px] text-slate-400">
          Simulate incoming messages without exposing private accounts
        </span>
      </div>

      <div className="mt-3.5 flex flex-wrap gap-2 items-center">
        {presets.map((preset) => {
          const Icon = preset.icon;
          const isLoading = isSimulating && activeScenario === preset.type;

          return (
            <button
              key={preset.type}
              onClick={() => handleSimulate(preset.type)}
              disabled={isSimulating}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium border bg-slate-950/60 transition-all active:scale-95 disabled:opacity-50 ${preset.color}`}
            >
              {isLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Icon className="w-3.5 h-3.5" />
              )}
              <span>{preset.label}</span>
            </button>
          );
        })}

        <button
          onClick={() => handleSimulate('RANDOM')}
          disabled={isSimulating}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white shadow transition-all active:scale-95 disabled:opacity-50"
        >
          {isSimulating && activeScenario === 'RANDOM' ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5" />
          )}
          <span>Random Simulation</span>
        </button>
      </div>
    </div>
  );
}
