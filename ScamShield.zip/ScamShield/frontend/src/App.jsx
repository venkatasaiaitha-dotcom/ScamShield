import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import BottomNav from './components/BottomNav';
import AlertModal from './components/AlertModal';
import AnalysisModal from './components/AnalysisModal';
import DashboardView from './views/DashboardView';
import AlertsView from './views/AlertsView';
import HistoryView from './views/HistoryView';
import SourcesView from './views/SourcesView';
import SafetyView from './views/SafetyView';
import SettingsView from './views/SettingsView';
import { api, createWebSocketClient, playAlertChime } from './services/api';

export default function App() {
  const [currentTab, setCurrentTab] = useState('home');
  const [agentStatus, setAgentStatus] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [history, setHistory] = useState([]);
  const [sources, setSources] = useState([]);
  const [settings, setSettings] = useState({
    protection_enabled: true,
    auto_alert_high: true,
    auto_alert_suspicious: true,
    high_risk_threshold: 70,
    suspicious_threshold: 30,
    privacy_minimal_metadata: true,
    sound_alerts: true,
  });

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [wsConnected, setWsConnected] = useState(false);
  const [loadingToggle, setLoadingToggle] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isSendingCustom, setIsSendingCustom] = useState(false);

  // Modals
  const [activeIncomingAlert, setActiveIncomingAlert] = useState(null);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);

  // Search & Filter in History
  const [searchTerm, setSearchTerm] = useState('');
  const [activeRiskFilter, setActiveRiskFilter] = useState('ALL');

  // Initial Data Load
  const fetchAllData = useCallback(async () => {
    try {
      const [statusData, alertsData, historyData, sourcesData, settingsData] = await Promise.all([
        api.getAgentStatus(),
        api.getAlerts(),
        api.getHistory(activeRiskFilter, searchTerm),
        api.getSources(),
        api.getSettings(),
      ]);

      setAgentStatus(statusData);
      setAlerts(alertsData);
      setHistory(historyData);
      setSources(sourcesData);
      setSettings(settingsData);
      setSoundEnabled(settingsData.sound_alerts);
    } catch (err) {
      console.error('Error fetching initial ScamShield data:', err);
    }
  }, [activeRiskFilter, searchTerm]);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // WebSocket Live Real-Time Message Listener
  useEffect(() => {
    const wsClient = createWebSocketClient(
      (message) => {
        if (message.event === 'INITIAL_SYNC') {
          if (message.data?.stats) {
            setAgentStatus((prev) => ({
              ...(prev || {}),
              ...message.data.stats,
            }));
          }
        } else if (message.event === 'MESSAGE_PROCESSED') {
          const { analysis, stats, notification_tier } = message.data;

          // Update stats dynamically
          if (stats) {
            setAgentStatus((prev) => ({
              ...(prev || {}),
              ...stats,
            }));
          }

          // Prepend to history & recent items
          setHistory((prev) => [analysis, ...prev.filter((item) => item.id !== analysis.id)]);

          // Check notification tier
          if (notification_tier === 'PROMINENT_ALERT') {
            if (soundEnabled) playAlertChime(true);
            setActiveIncomingAlert(analysis);
            // Append alert item
            setAlerts((prev) => [
              {
                id: `alt-${analysis.id}`,
                analysis_id: analysis.id,
                risk_level: analysis.risk_level,
                risk_score: analysis.risk_score,
                category: analysis.category,
                sender: analysis.sender,
                summary: analysis.summary,
                timestamp: analysis.timestamp,
                is_read: false,
                reasons_summary: (analysis.reasons || []).map((r) => r.title || r),
              },
              ...prev,
            ]);
          } else if (notification_tier === 'SUBTLE_NOTICE') {
            if (soundEnabled) playAlertChime(false);
            setAlerts((prev) => [
              {
                id: `alt-${analysis.id}`,
                analysis_id: analysis.id,
                risk_level: analysis.risk_level,
                risk_score: analysis.risk_score,
                category: analysis.category,
                sender: analysis.sender,
                summary: analysis.summary,
                timestamp: analysis.timestamp,
                is_read: false,
                reasons_summary: (analysis.reasons || []).map((r) => r.title || r),
              },
              ...prev,
            ]);
          } else if (message.event === 'DATA_WIPED') {
            setHistory([]);
            setAlerts([]);
            if (message.data?.stats) {
              setAgentStatus((prev) => ({
                ...(prev || {}),
                ...message.data.stats,
              }));
            }
          }
        }
      },
      (connected) => setWsConnected(connected)
    );

    return () => wsClient.disconnect();
  }, [soundEnabled]);

  // Protection Switch Toggle
  const handleToggleProtection = async () => {
    setLoadingToggle(true);
    try {
      if (agentStatus?.protection_active) {
        await api.pauseProtection();
      } else {
        await api.startProtection();
      }
      const updated = await api.getAgentStatus();
      setAgentStatus(updated);
    } catch (err) {
      console.error('Failed to toggle protection:', err);
    } finally {
      setLoadingToggle(false);
    }
  };

  // Preset Scenario Simulator Trigger
  const handleTriggerScenario = async (scenarioType) => {
    setIsSimulating(true);
    try {
      const res = await api.simulateScenario(scenarioType);
      // Fallback update if websocket is not instant
      setHistory((prev) => [res, ...prev.filter((i) => i.id !== res.id)]);
      const updatedStatus = await api.getAgentStatus();
      setAgentStatus(updatedStatus);
      return res;
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Custom Message Submission
  const handleSendCustomMessage = async (msgData) => {
    setIsSendingCustom(true);
    try {
      const res = await api.sendIncomingMessage(msgData);
      setHistory((prev) => [res, ...prev.filter((i) => i.id !== res.id)]);
      const updatedStatus = await api.getAgentStatus();
      setAgentStatus(updatedStatus);
      setSelectedAnalysis(res);
      return res;
    } catch (err) {
      console.error('Error analyzing custom message:', err);
    } finally {
      setIsSendingCustom(false);
    }
  };

  // Alert Handlers
  const handleMarkAlertRead = async (alertId) => {
    try {
      await api.markAlertRead(alertId);
      setAlerts((prev) =>
        prev.map((a) => (a.id === alertId ? { ...a, is_read: true } : a))
      );
    } catch (err) {
      console.error('Error marking alert read:', err);
    }
  };

  const handleMarkAllAlertsRead = async () => {
    try {
      await api.markAllAlertsRead();
      setAlerts((prev) => prev.map((a) => ({ ...a, is_read: true })));
    } catch (err) {
      console.error('Error marking all alerts read:', err);
    }
  };

  // Drilldown to full analysis modal
  const handleViewAnalysisDetail = async (item) => {
    try {
      const analysisId = item.analysis_id || item.id;
      const detail = await api.getHistoryDetail(analysisId);
      setSelectedAnalysis(detail);
    } catch {
      setSelectedAnalysis(item);
    }
  };

  // History Actions
  const handleDeleteHistoryEntry = async (id) => {
    try {
      await api.deleteHistoryEntry(id);
      setHistory((prev) => prev.filter((i) => i.id !== id));
      setAlerts((prev) => prev.filter((a) => a.analysis_id !== id));
      const updatedStatus = await api.getAgentStatus();
      setAgentStatus(updatedStatus);
    } catch (err) {
      console.error('Error deleting history entry:', err);
    }
  };

  const handleClearHistory = async () => {
    try {
      const res = await api.wipeAllData();
      setHistory([]);
      setAlerts([]);
      if (res.stats) {
        setAgentStatus((prev) => ({ ...(prev || {}), ...res.stats }));
      } else {
        const updatedStatus = await api.getAgentStatus();
        setAgentStatus(updatedStatus);
      }
    } catch (err) {
      console.error('Error wiping data:', err);
    }
  };

  const handleMessageAnalyzed = (newAnalysis) => {
    setHistory((prev) => [newAnalysis, ...prev.filter((i) => i.id !== newAnalysis.id)]);
    api.getAgentStatus().then(setAgentStatus);
  };

  // Source Actions
  const handleConnectSource = async (sourceId) => {
    try {
      await api.connectSource(sourceId);
      const updatedSources = await api.getSources();
      setSources(updatedSources);
      const updatedStatus = await api.getAgentStatus();
      setAgentStatus(updatedStatus);
    } catch (err) {
      console.error('Error connecting source:', err);
    }
  };

  const handleDisconnectSource = async (sourceId) => {
    try {
      await api.disconnectSource(sourceId);
      const updatedSources = await api.getSources();
      setSources(updatedSources);
      const updatedStatus = await api.getAgentStatus();
      setAgentStatus(updatedStatus);
    } catch (err) {
      console.error('Error disconnecting source:', err);
    }
  };

  // Settings Save
  const handleSaveSettings = async (newSettings) => {
    const updated = await api.updateSettings(newSettings);
    setSettings(updated);
    setSoundEnabled(updated.sound_alerts);
    const updatedStatus = await api.getAgentStatus();
    setAgentStatus(updatedStatus);
  };

  const unreadAlertsCount = alerts.filter((a) => !a.is_read).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950 pb-20 md:pb-8">
      {/* Top Navbar */}
      <Navbar
        agentStatus={agentStatus}
        wsConnected={wsConnected}
        unreadCount={unreadAlertsCount}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenAlerts={() => setCurrentTab('alerts')}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6">
        {currentTab === 'home' && (
          <DashboardView
            agentStatus={agentStatus}
            onToggleProtection={handleToggleProtection}
            loadingToggle={loadingToggle}
            onTriggerScenario={handleTriggerScenario}
            isSimulating={isSimulating}
            recentAnalyses={history}
            onViewAnalysis={handleViewAnalysisDetail}
            onNavigateHistory={() => setCurrentTab('history')}
            onMessageAnalyzed={handleMessageAnalyzed}
          />
        )}

        {currentTab === 'alerts' && (
          <AlertsView
            alerts={alerts}
            onMarkRead={handleMarkAlertRead}
            onMarkAllRead={handleMarkAllAlertsRead}
            onViewAnalysis={handleViewAnalysisDetail}
          />
        )}

        {currentTab === 'history' && (
          <HistoryView
            history={history}
            onSearch={setSearchTerm}
            onFilterRisk={setActiveRiskFilter}
            activeRiskFilter={activeRiskFilter}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onDeleteEntry={handleDeleteHistoryEntry}
            onClearHistory={handleClearHistory}
            onViewAnalysis={handleViewAnalysisDetail}
          />
        )}

        {currentTab === 'sources' && (
          <SourcesView
            sources={sources}
            onConnectSource={handleConnectSource}
            onDisconnectSource={handleDisconnectSource}
            onSendCustomMessage={handleSendCustomMessage}
            isSendingCustom={isSendingCustom}
            onMessageAnalyzed={handleMessageAnalyzed}
            onViewAnalysis={handleViewAnalysisDetail}
          />
        )}

        {currentTab === 'safety' && <SafetyView />}

        {currentTab === 'settings' && (
          <SettingsView
            settings={settings}
            onSaveSettings={handleSaveSettings}
            onClearHistory={handleClearHistory}
          />
        )}
      </main>

      {/* Prominent High-Risk Warning Modal */}
      {activeIncomingAlert && (
        <AlertModal
          alert={activeIncomingAlert}
          onClose={() => setActiveIncomingAlert(null)}
          onViewDetails={(alt) => {
            setActiveIncomingAlert(null);
            handleViewAnalysisDetail(alt);
          }}
        />
      )}

      {/* Full Analysis Drilldown Modal */}
      {selectedAnalysis && (
        <AnalysisModal
          analysis={selectedAnalysis}
          onClose={() => setSelectedAnalysis(null)}
        />
      )}

      {/* Mobile-First Bottom Navigation Bar */}
      <BottomNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        unreadCount={unreadAlertsCount}
      />
    </div>
  );
}
